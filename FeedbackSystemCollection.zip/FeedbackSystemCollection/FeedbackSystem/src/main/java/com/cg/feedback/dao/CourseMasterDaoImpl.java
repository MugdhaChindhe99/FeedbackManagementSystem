package com.cg.feedback.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.feedback.model.CourseMaster;

public class CourseMasterDaoImpl implements CourseMasterDao {

	private HashMap<Long, CourseMaster> course;

	public CourseMasterDaoImpl() {
		course = new HashMap<Long, CourseMaster>();
	}

	public CourseMaster addCourse(CourseMaster c) {
		course.put(c.getCourseId(), c);

		return c;
	}

	public CourseMaster updateCourse(CourseMaster c) {
		return course.replace(c.getCourseId(), c);
	}

	public List<CourseMaster> findAll() {
		List<CourseMaster> fin = new ArrayList<CourseMaster>(course.values());
		return fin;

	}

	public CourseMaster findById(long courseId) {
		{
			CourseMaster c2 = course.get(courseId);
			return c2;
		}

	}

	@Override
	public CourseMaster getCourse(long cid) {
		// TODO Auto-generated method stub
		return course.get(cid);
	}

}
