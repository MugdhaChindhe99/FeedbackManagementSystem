package com.cg.feedback.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.feedback.exception.FeedbackException;
import com.cg.feedback.model.Feedback;

public class FeedbackDaoImpl implements FeedbackDao{

	 private static final Map<Long,Feedback> feedback=new HashMap<Long,Feedback>();
	 
		public FeedbackDaoImpl() throws Exception {
		
		}
	
	public Feedback giveFeedback(Feedback fb) throws Exception {
		 feedback.put(fb.getFeedbackId(),fb);
		 return fb;

	}

	public List<Feedback> showFeedbackReport() throws FeedbackException {
		// TODO Auto-generated method stub
		List<Feedback> feed=new ArrayList<Feedback>(feedback.values());
		return feed;
	}

	public Feedback findById(long iD) {
		return feedback.get(iD);
		
	}

	

	

}
