package com.cg.feedback.exception;

public class FeedbackException extends Exception{

}
