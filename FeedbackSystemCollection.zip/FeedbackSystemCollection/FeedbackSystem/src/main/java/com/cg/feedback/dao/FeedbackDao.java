package com.cg.feedback.dao;

import java.util.List;

import com.cg.feedback.exception.FeedbackException;
import com.cg.feedback.model.Feedback;

public interface FeedbackDao {
	
Feedback giveFeedback(Feedback fb) throws Exception;
	
	List<Feedback>showFeedbackReport() throws FeedbackException;

	 Feedback findById(long iD);

}
