package com.cg.feedback.model;

public class CourseMaster {

	
	private long courseId;
	private String courseName;
	private long noOfDays;
	private Skill skill;
	
	
	
	public long getCourseId() {
		return courseId;
	}
	public void setCourseId(long courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public long getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(Long time) {
		this.noOfDays = time;
	}
	public Skill getSkill() {
		return skill;
	}
	public void setSkill(Skill skill) {
		this.skill = skill;
	}
	public CourseMaster() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CourseMaster(int courseId, String courseName, int noOfDays) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.noOfDays = noOfDays;
		//this.skill = skill;
	}
	@Override
	public String toString() {
		return "CourseMaster [courseId=" + courseId + ", courseName=" + courseName + ", noOfDays=" + noOfDays + "]";
	}
	
	
	
	
	
	
	
}
