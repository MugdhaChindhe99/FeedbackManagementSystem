package com.cg.feedback.dao;

import java.util.List;

import com.cg.feedback.model.Employee;
import com.cg.feedback.model.Skill;

public interface EmployeeDao {
	public Employee login(long empId, String password);

	public List<Employee> findAll() throws Exception;

	public void addEmployee() throws Exception;

	public Employee find(long empId) throws Exception;

	public String updateEmployee(Employee empl) throws Exception;

	public Employee findById(long empId) throws Exception;

	public Employee addEmployee(Employee empl);

	public Employee password(long pass);

}
