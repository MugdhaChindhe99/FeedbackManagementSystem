package com.cg.feedback.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;

import com.cg.feedback.exception.FeedbackException;
import com.cg.feedback.exception.userException;
import com.cg.feedback.model.CourseMaster;
import com.cg.feedback.model.Employee;
import com.cg.feedback.model.Feedback;
import com.cg.feedback.model.TrainingProgram;
import com.cg.feedback.service.CourseService;
import com.cg.feedback.service.CourseServiceImpl;
import com.cg.feedback.service.EmployeeService;
import com.cg.feedback.service.EmployeeServiceImpl;
import com.cg.feedback.service.FeedbackService;
import com.cg.feedback.service.FeedbackServiceImpl;
import com.cg.feedback.service.TrainingProgramService;
import com.cg.feedback.service.TrainingProgramServiceImpl;

public class Coordinator {
	Employee empl;
	CourseMaster cmaster;
	CourseService cservice;
	//TrainingProgramService tservice;
	EmployeeService emp;
	TrainingProgramService tservice;
	Feedback feedback=new Feedback();
	static List<Employee> participantList = new ArrayList<Employee>();
	TrainingProgram tprogram = new TrainingProgram();
	FeedbackService fservice = new FeedbackServiceImpl();
	LocalDate date1;
	LocalDate date2;
	public Coordinator() {
		empl = new Employee();
		cmaster = new CourseMaster();
		cservice = CourseServiceImpl.getCourseServiceImpl();
		tservice =TrainingProgramServiceImpl.getTrainingProgramServiceImpl();
		emp = new EmployeeServiceImpl();
	}

	public void show() throws Exception {
		System.out.println(
				"What u want to do : \n 1.Add Training Program\n2.View Training Program Details\n3.Update Training Program\n4.View Feedback details by id\n5.View all Feedback\n6.LogOut");

		int option = FeedbackSystemUI.scanner.nextInt();

		switch (option) {

		case 1:
			addTrainingprogram();
			break;

		case 2:
			viewAllPrograms();
			break;

		case 3:
			 updateTrainingProgram();
			 break;
			 
		case 4:
			viewFeedbackById();
			break;
		case 5:
			viewAllFeedback();
			break;
		case 6:
			FeedbackSystemUI.login();
			break;

		}

	}
	
	public void viewAllFeedback() throws FeedbackException {
		List<Feedback> feedList = fservice.showFeedbackReport();
		fservice.showFeedbackReport().forEach(System.out::println);

	}
	
	public void viewFeedbackById()
	{
		do {
			try {
		System.out.println("Enter FeedBack Id :");
		long ID = FeedbackSystemUI.scanner.nextLong();
		feedback = fservice.findById(ID);
		if(feedback!=null) {
		System.out.println(feedback);
		}
		else
			throw new userException();
	}
			catch(userException exp)
			{
				System.out.println("Invalid feedbackId");
			}
			catch(InputMismatchException e)
			{
				System.out.println("Invalid Input");
			}
				}while(true);
			}
	

	public void addTrainingprogram() throws Exception {

		//TrainingProgram tprogram = new TrainingProgram();

		System.out.println("Enter Training Program ID:");
		long id = FeedbackSystemUI.scanner.nextLong();
		FeedbackSystemUI.scanner.nextLine();

		System.out.println("Select Course for Training Program : \n ");
		List<CourseMaster> course = cservice.findAll();
		course.stream().forEach(System.out::println);
		System.out.println("Enter Course ID");
		long cid = FeedbackSystemUI.scanner.nextLong();
		CourseMaster cm = cservice.getCourse(cid);
do {
		System.out.println("Enter Start Date For Training Program(dd/MM/yyyy)");
		String Datestrt = FeedbackSystemUI.scanner.next();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date1 = LocalDate.parse(Datestrt, dtf);

		System.out.println("Enter End Date For Training Program(dd/MM/yyyy)");
		String Dateend = FeedbackSystemUI.scanner.next();
		date2 = LocalDate.parse(Dateend, dtf);
		
		if((date1.compareTo(date2))<0)
		break;
		else
			System.out.println("Start Date Cannot be less than end date");
}while(true);
	System.out.println("Enter Hours per day of course :");
		long hrs = FeedbackSystemUI.scanner.nextLong();

		System.out.println("Enter Employee ID to assign as trainer");
		Employee employee = emp.findById(FeedbackSystemUI.scanner.nextLong());

		int s;
		do {

			System.out.println("Enter particpant ID to assign as course");
			participantList.add(emp.findById(FeedbackSystemUI.scanner.nextLong()));
			System.out.println("type 0 if want to brk");
			s = FeedbackSystemUI.scanner.nextInt();
		} while (s != 0);

		tprogram.setCourse(cm);
		tprogram.setTrainingProgramId(id);
		tprogram.setParticipant(participantList);
		tprogram.setStartDate(date1);
		tprogram.setEndDate(date2);
		tprogram.setHourPerDay(hrs);
		tprogram.setTrainer(employee);

		TrainingProgram tp = tservice.addTrainingProgram(id, tprogram);
		System.out.println(tp);
		show();

	}

	public void viewAllPrograms() throws Exception {
		List<TrainingProgram> tmp = tservice.view();
		tmp.stream().forEach(System.out::println);
		show();

	}

	public void updateTrainingProgram() throws Exception {
		//TrainingProgram tprogram = new TrainingProgram();
		System.out.println("Enter Training Program ID you want to update :");
		long id = FeedbackSystemUI.scanner.nextLong();
		TrainingProgram training = new TrainingProgram();
		training = tservice.viewById(id);
		System.out.println("What you want to update :");
		System.out.println(
				"\n1.Training Course \n2.Training Start Date\n3.Training End Date\n4.Hour per Day\n5.Trainer\n6.Add Participants");
		int choice = FeedbackSystemUI.scanner.nextInt();
		FeedbackSystemUI.scanner.nextLine();
		switch (choice) {
		case 1: {
			System.out.println("Select Course for Training Program : \n ");
			List<CourseMaster> course = cservice.findAll();
			course.stream().forEach(System.out::println);
			do {
			System.out.println("Enter Course ID");
			long cid = FeedbackSystemUI.scanner.nextLong();
			CourseMaster cm = cservice.getCourse(cid);
			if(cm!=null){
			tprogram.setCourse(cm);
			break;
			}
			else {
				System.out.println("Enter Valid Course ID");
			}
			break;
		}while(true);
			
		}
		case 2: {
			System.out.println("Enter Start Date For Training Program");
			String Datestrt = FeedbackSystemUI.scanner.next();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate date1 = LocalDate.parse(Datestrt, dtf);
			tprogram.setStartDate(date1);
			break;

		}

		case 3: {
			System.out.println("Enter End Date For Training Program");
			String Dateend = FeedbackSystemUI.scanner.next();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate date2 = LocalDate.parse(Dateend, dtf);
			tprogram.setEndDate(date2);
			break;
		}
		case 4: {
			System.out.println("Enter Hours per day of course :");
			long hrs = FeedbackSystemUI.scanner.nextLong();
			tprogram.setHourPerDay(hrs);
			break;
		}
		case 5: do{
			System.out.println("Enter Employee ID to assign as trainer");
			Employee employee = emp.findById(FeedbackSystemUI.scanner.nextLong());
			if(employee!=null) {
			tprogram.setTrainer(employee);
			break;
			}
			else
				System.out.println("Enter valid Employee Id");
		}while(true);

		case 6: {
			int s;
			do {

				System.out.println("Enter particpant ID to assign as course");
				participantList	.add(emp.findById(FeedbackSystemUI.scanner.nextLong()));
				System.out.println("type 0 if want to brk");
				s = FeedbackSystemUI.scanner.nextInt();
			} while (s != 0);
			tprogram.setParticipant(participantList);
			break;
		}
		}
		TrainingProgram t = tservice.update(tprogram);
		System.out.println(t);
		show();

	}

}
