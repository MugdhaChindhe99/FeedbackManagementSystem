package com.cg.feedback.service;

import java.util.List;

import com.cg.feedback.exception.FeedbackException;
import com.cg.feedback.model.Feedback;

public interface FeedbackService {

    Feedback giveFeedback(Feedback fb) throws Exception;
	
	List<Feedback>showFeedbackReport() throws FeedbackException;

	Feedback findById(long iD);

	
}
