package com.cg.feedback.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.feedback.exception.FeedbackException;
import com.cg.feedback.model.Skill;
import com.cg.feedback.store.Store;

public class SkillDaoImpl implements SkillDao{

	
	private static Map<Long,Skill> skillMap=new HashMap<>();
	public Store store;
	public SkillDaoImpl() throws Exception {
//		store=Store.getInstatnce();
//		skillMap=Store.getInstatnce().getSkills();
	}

	
	
	
	public Skill addSkills(Skill skill)// throws FeedbackException, Exception
	{
		skillMap.put(skill.getSkillId(), skill);
		addDataToFile();
		return skill;
	}
	
	private void addDataToFile() //throws Exception 
	{
		
		skillMap.put((long)111,new Skill(111,"Python"));
		skillMap.put((long)112,new Skill(111,"Java"));
		skillMap.put((long)113,new Skill(111,"C#"));
		skillMap.put((long)114,new Skill(111,"C++"));
		skillMap.put((long)115,new Skill(111,"Oracle"));
		
	//		store.setSkills(skillMap);
   //		store.Save();
		System.out.println("Done");
	}


	public List<Skill> findAll() {
		List<Skill> skill=new ArrayList<Skill>(skillMap.values());
		return skill;
	}

	public Skill findById(long empId) {
		return skillMap.get(empId);

	}

	
	

}
