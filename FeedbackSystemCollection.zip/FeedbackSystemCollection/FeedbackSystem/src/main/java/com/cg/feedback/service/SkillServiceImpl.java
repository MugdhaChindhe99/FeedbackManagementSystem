package com.cg.feedback.service;

import java.util.List;

import com.cg.feedback.dao.SkillDao;
import com.cg.feedback.dao.SkillDaoImpl;
import com.cg.feedback.exception.FeedbackException;
import com.cg.feedback.model.Skill;

public class SkillServiceImpl implements SkillService {

	SkillDao da;
	
	
	public SkillServiceImpl() //throws Exception
	{
		try {
			da=new SkillDaoImpl();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public Skill addSkills(Skill skill)// throws FeedbackException, Exception 
	{
	Skill s1 = null;
	try {
		s1 = da.addSkills(skill);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		return s1;

	}

	public List<Skill> findAll() {
		List<Skill> s=da.findAll();
		return s;
	}

	public Skill findById(long empId) {
		Skill s2=da.findById(empId);		
		return s2;

	}

}
