package com.cg.feedback.exception;

public class InvalidLoginException extends Exception {

	public InvalidLoginException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidLoginException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "InvalidLoginException";
	}

}
