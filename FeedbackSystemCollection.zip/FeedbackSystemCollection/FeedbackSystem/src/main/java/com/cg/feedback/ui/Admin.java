 package com.cg.feedback.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.omg.CORBA.UserException;

import com.cg.feedback.exception.FeedbackException;
import com.cg.feedback.exception.InvalidEmployeeException;
import com.cg.feedback.exception.userException;
import com.cg.feedback.exception.viewByEmployeeException;
import com.cg.feedback.model.CourseMaster;
import com.cg.feedback.model.Employee;
import com.cg.feedback.model.Feedback;
import com.cg.feedback.model.Skill;
import com.cg.feedback.model.TrainingProgram;
import com.cg.feedback.service.CourseService;
import com.cg.feedback.service.CourseServiceImpl;
import com.cg.feedback.service.EmployeeService;
import com.cg.feedback.service.EmployeeServiceImpl;
import com.cg.feedback.service.FeedbackService;
import com.cg.feedback.service.FeedbackServiceImpl;
import com.cg.feedback.service.SkillService;
import com.cg.feedback.service.SkillServiceImpl;
import com.cg.feedback.service.TrainingProgramService;
import com.cg.feedback.service.TrainingProgramServiceImpl;


public class Admin {
	EmployeeService userfetch = new EmployeeServiceImpl();
	Employee empl = new Employee();
	CourseMaster course = new CourseMaster();
	CourseService cservice = CourseServiceImpl.getCourseServiceImpl();
	Feedback feed = new Feedback();
	FeedbackService fservice = new FeedbackServiceImpl();
	SkillService skillService=new SkillServiceImpl();
	Set<Skill> skillSet = new TreeSet<>();
	Set<TrainingProgram> trainingProgramParticipatedSet = new TreeSet<TrainingProgram>();
	TrainingProgramService tservice;
	
	
	public Admin()
	{
		tservice=TrainingProgramServiceImpl.getTrainingProgramServiceImpl();
	}
	public void show() throws Exception {
do {
		System.out.println(
				"What u want to do : \n 1.Update Employee\n2.View Employee Details\n3.View all Employee\n4.Add Course\n5.Update Course\n6.View Course(By ID)\n7.View All Courses\n8.View Feedback\n9.Add Employee\n10.LogOut");
try {
		int option = FeedbackSystemUI.scanner.nextInt();

		switch (option) {

		case 1:
			UpdateEmployee();
			break;

		case 2:
			viewByEmployeeId();
			break;
		case 3:
			viewAllEmployee();
			break;

		case 4:
			addCourse();
			break;
		case 5:
			updateCourse();
			break;
		case 6:
			viewByCourseId();
			break;

		case 7:
			viewAllCourse();
			break;
			
		case 8:
			viewAllFeedback();
			break;
			
		case 9:
			addEmployee();
			break;

		case 10:
			FeedbackSystemUI.login();
			break;
		}
}
catch(InputMismatchException e)
{
		System.out.println("Invalid Input");
	}
FeedbackSystemUI.scanner.nextLine();
	}while(true);
	}	
	
	public void UpdateEmployee() throws Exception {
		try {
		System.out.println("Enter employee ID you want to update :");
		long id = FeedbackSystemUI.scanner.nextLong();
		//Employee emp2 = new Employee();
		Employee emp2 = userfetch.findById(id);
		if(emp2==null)
			throw new InvalidEmployeeException();
		System.out.println("What you want to update :");
		System.out.println("\n1.Employee Name\n2.Employee Password\n3.Employee role\n");
		int choice = FeedbackSystemUI.scanner.nextInt();
		FeedbackSystemUI.scanner.nextLine();
		switch (choice) {
		case 1: do{
			
			System.out.println("Enter Name :");
			String name = FeedbackSystemUI.scanner.nextLine();
			if(EmployeeService.validateName(name))
			{
			emp2.setEmployeeName(name);
			break;
			}
			else
			{
			System.out.println("Pattern MisMatch");
			}
		}while(true);
		break;
		case 2: do{
			System.out.println("Enter Password :");
			String pass = FeedbackSystemUI.scanner.nextLine();
			if(EmployeeService.validatePassword(pass))
			{
			emp2.setPassword(pass);
			break;
			}
			else
			{
				System.out.println("password patttern mismatch..Enter 4 digit no. as password");
			}
		}while(true);
		break;

		case 3: do{
			System.out.println("Enter Employee Role :");
			String role = FeedbackSystemUI.scanner.nextLine();
			if(EmployeeService.validateName(role))
			{
			emp2.setRole(role);
			break;
			}
			else
			{
				System.out.println("Enter valid Role Name");
			}
		}while(true);
		break;

		}
		String result = userfetch.updateEmployee(emp2);
		System.out.println("" + result);
		show();

	}
		catch(InvalidEmployeeException exp)
		{
			System.out.println("Check Employee Id");
		}
		catch(InputMismatchException ex)
		{
			System.out.println("Enter valid Input ");
		}
	}

	public void viewByEmployeeId() throws Exception {
		System.out.println("Enter Employee Id :");
		long ID = FeedbackSystemUI.scanner.nextLong();
		try {
		empl = userfetch.findById(ID);
		if(empl==null)
			throw new viewByEmployeeException();
		System.out.println(empl);
		}catch(viewByEmployeeException exp)
		{
			System.out.println("Check Employee Id");
			viewByEmployeeId();
		}
	
	}

	public void viewAllEmployee() throws Exception {
		try {
		List<Employee> emp = userfetch.findAll();
		if(emp==null)
			throw new userException();
		emp.stream().forEach(System.out::println);
		}
		catch(UserException exp)
		{
			System.out.println("No users to Display");
		}
	}

	public void addCourse() {
		CourseMaster cor = new CourseMaster();
			
		System.out.println("Enter Course Details");
		
		System.out.println("Enter Course Id :");
		long id=FeedbackSystemUI.scanner.nextLong();
		cor.setCourseId(id);
		FeedbackSystemUI.scanner.nextLine();
		do {
		System.out.println("Enter Course Name :");
		String cname=FeedbackSystemUI.scanner.nextLine();
		if(CourseService.validateName(cname))
		{
		cor.setCourseName(cname);
		break;
		}
		else {
			System.out.println("Enter valid Course Name");
		}
		}while(true);
		System.out.println("Enter Course duration(in hrs) :");
		cor.setNoOfDays(FeedbackSystemUI.scanner.nextLong());

		CourseMaster c = cservice.addCourse(cor);
		System.out.println(c);
		
		
	}
	
	
	
	public void updateCourse() throws Exception {
		System.out.println("Enter Course ID you want to update :");
		long id = FeedbackSystemUI.scanner.nextLong();
		CourseMaster coursem = new CourseMaster();
		coursem = cservice.findById(id);
		System.out.println("What you want to update :");
		System.out.println("\n1.Course ID\n2.Course Name\n3.Course Duration\n");
		int choice = FeedbackSystemUI.scanner.nextInt();
		FeedbackSystemUI.scanner.nextLine();
		switch (choice) {
		case 1: {
			System.out.println("Enter Course Id :");
			coursem.setCourseId(FeedbackSystemUI.scanner.nextLong());
			break;
		}
		case 2: {
			do {
			System.out.println("Enter CourseName");
			String cname=FeedbackSystemUI.scanner.nextLine();
			if(CourseService.validateName(cname))
			{
			coursem.setCourseName(cname);
			break;
			}
			else
			{
				System.out.println("Enter valid Name");
			}
			}while(true);
		}
			

		case 3: {
			System.out.println("Enter Course Duration :");
			coursem.setNoOfDays(FeedbackSystemUI.scanner.nextLong());
			break;

		}

		}
		CourseMaster c = cservice.updateCourse(coursem);
		System.out.println(c);
		show();

	

	}

	public void viewByCourseId() {
		try{
		System.out.println("Enter Course Id :");
		long id=FeedbackSystemUI.scanner.nextLong();
		course = cservice.findById(id);
		if(course!=null)
		System.out.println(course);
		else
			throw new userException();
		}
		catch(userException exp)
		{
		System.out.println("Enter valid Course Id");
		
		}
		}

	public void viewAllCourse() {
		List<CourseMaster> cmaster = cservice.findAll();
		cservice.findAll().forEach(System.out::println);
	}

	public void viewAllFeedback() throws FeedbackException {
		List<Feedback> feedList = fservice.showFeedbackReport();
		fservice.showFeedbackReport().forEach(System.out::println);

	}
	
	public void viewFeedbackById()
	{
		try {
		System.out.println("Enter FeedBack Id :");
		long ID = FeedbackSystemUI.scanner.nextLong();
		feed = fservice.findById(ID);
		if(feed!=null)			
		System.out.println(feed);
		else
			throw new userException(); 
	}
		catch(userException exp)
		{
			System.out.println("");
		}
		}
	
	public void addEmployee() 
	{
		
		long id;
		String tmpName;
		List<Skill> demoList=new ArrayList<>();
		do {
			System.out.println("Enter Employee ID:");
			id=FeedbackSystemUI.scanner.nextLong();
			FeedbackSystemUI.scanner.nextLine();
			
			System.out.println("Enter name");
			 tmpName = FeedbackSystemUI.scanner.nextLine();
			if (tmpName.matches(userfetch.namePattern))
				break;
			else
				System.out.println("Invalid Name");
		} while (true);
		System.out.println("Enter role");
		String tmpRole = FeedbackSystemUI.scanner.nextLine();
		System.out.println("Enter Password");
		String tmpPassword = FeedbackSystemUI.scanner.nextLine();
		System.out.println("Select skill you possess");
		int y = 1;// To close loop set y=0
		do {
			System.out.println("1- Java\t 2- C\t 3-C++\t 4-Python\t 5-HTML\n 6-JavaScript\t 7-JQuery\t 8-Done");
			switch (FeedbackSystemUI.scanner.nextInt()) {
			case 1:
				demoList.add(skillService.findById(1111));
				break;
			case 2:
				demoList.add(skillService.findById(2222));
				break;
			case 3:
				demoList.add(skillService.findById(3333));
				break;
			case 4:
				demoList.add(skillService.findById(4444));
				break;
			case 5:
				demoList.add(skillService.findById(5555));
				break;
			case 6:
				demoList.add(skillService.findById(6666));
				break;
			case 7:
				demoList.add(skillService.findById(7777));
				break;
			case 8:
				y = 0;
				break;
			}
		} while (y != 0);
		y = 1;
		
		System.out.println("Enter code of training program participated");
		do {
			List<TrainingProgram> tlist = tservice.findAll();
			tlist.stream().forEach(System.out::println);
			try {
				trainingProgramParticipatedSet.add(tservice.viewById(FeedbackSystemUI.scanner.nextLong()));
			} catch (FeedbackException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			FeedbackSystemUI.scanner.nextLine();
			System.out.println("want to continue 1/0");
			 y = FeedbackSystemUI.scanner.nextInt();
			 FeedbackSystemUI.scanner.nextLine();
		} while (y != 0);

		empl.setEmployeeName(tmpName);
		empl.setPassword(tmpPassword);
		empl.setRole(tmpRole);
		empl.setSkills(demoList.stream().collect(Collectors.toSet()));
		//tmpEmployee.setTrainingProgramConducted(trainingProgramConductedSet);
		empl.setTrainingProgramParticipated(trainingProgramParticipatedSet);
		empl.setEmployeeId(id);
		System.out.println("Employee added with id :" + userfetch.addEmployee(empl));
	}

	public void updateEmployee() 
	{
		/*
		 * EmployeeService userfetch = new EmployeeServiceImpl(); 
		 * Employee empl = newEmployee();
		 *  CourseMaster course = new CourseMaster(); 
		 *  CourseService cservice= CourseServiceImpl.getCourseServiceImpl(); 
		 *  Feedback feed = new Feedback();
		 * FeedbackService fservice = new FeedbackServiceImpl();
		 *  Feedback feedback=new Feedback();
		 */
		long id;
		String tmpName;
		List<Skill> demoList=new ArrayList<>();
		do {
			System.out.println("Enter Employee ID:");
			id=FeedbackSystemUI.scanner.nextLong();
			FeedbackSystemUI.scanner.nextLine();
			System.out.println("Enter name");
			 tmpName = FeedbackSystemUI.scanner.nextLine();
			if (tmpName.matches(userfetch.namePattern))
				break;
			else
				System.out.println("Invalid Name");
		} while (true);
		System.out.println("Enter role");
		String tmpRole = FeedbackSystemUI.scanner.nextLine();
		System.out.println("Enter Password");
		String tmpPassword = FeedbackSystemUI.scanner.nextLine();
		System.out.println("Select skill you possess");
		int y = 1;// To close loop set y=0
		do {
			System.out.println("1- Java\t 2- C\t 3-C++\t 4-Python\t 5-HTML\n 6-JavaScript\t 7-JQuery\t 8-Done");
			switch (FeedbackSystemUI.scanner.nextInt()) {
			case 1:
				demoList.add(skillService.findById(1111));
				break;
			case 2:
				demoList.add(skillService.findById(2222));
				break;
			case 3:
				demoList.add(skillService.findById(3333));
				break;
			case 4:
				demoList.add(skillService.findById(4444));
				break;
			case 5:
				demoList.add(skillService.findById(5555));
				break;
			case 6:
				demoList.add(skillService.findById(6666));
				break;
			case 7:
				demoList.add(skillService.findById(7777));
				break;
			case 8:
				y = 0;
				break;
			}
		} while (y != 0);
		y = 1;
		
		System.out.println("Enter code of training program participated");
		do {
			List<TrainingProgram> tlist = tservice.findAll();
			tlist.stream().forEach(System.out::println);
			try {
				trainingProgramParticipatedSet.add(tservice.viewById(FeedbackSystemUI.scanner.nextLong()));
			} catch (FeedbackException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			FeedbackSystemUI.scanner.nextLine();
			System.out.println("want to continue 1/0");
			 y = FeedbackSystemUI.scanner.nextInt();
			 FeedbackSystemUI.scanner.nextLine();
		} while (y != 0);

		empl.setEmployeeName(tmpName);
		empl.setPassword(tmpPassword);
		empl.setRole(tmpRole);
		empl.setSkills(demoList.stream().collect(Collectors.toSet()));
		//tmpEmployee.setTrainingProgramConducted(trainingProgramConductedSet);
		empl.setTrainingProgramParticipated(trainingProgramParticipatedSet);
		empl.setEmployeeId(id);
		System.out.println("Employee added with id :" + userfetch.addEmployee(empl));
	}

}
