package com.cg.feedback.ui;

import java.util.InputMismatchException;

import com.cg.feedback.exception.userException;
import com.cg.feedback.model.Employee;
import com.cg.feedback.model.Feedback;
import com.cg.feedback.model.TrainingProgram;
import com.cg.feedback.service.EmployeeService;
import com.cg.feedback.service.EmployeeServiceImpl;
import com.cg.feedback.service.FeedbackService;
import com.cg.feedback.service.FeedbackServiceImpl;
import com.cg.feedback.service.TrainingProgramService;
import com.cg.feedback.service.TrainingProgramServiceImpl;

public class Participant {

	EmployeeService ser = new EmployeeServiceImpl();
	TrainingProgramService t = new TrainingProgramServiceImpl();
	Feedback feed = new Feedback();
	FeedbackService fservice = new FeedbackServiceImpl();

	public void show() throws Exception {
try {
		System.out.println("Enter FeedbackID");
		long fbId = FeedbackSystemUI.scanner.nextLong();

		System.out.println("Enter Participant Id:");
		long id = FeedbackSystemUI.scanner.nextLong();
	//	try {
			Employee emp = ser.findById(id);
			if(emp==null)
				throw new userException();
			{ 

				System.out.println("Enter training Program Id");
				TrainingProgram trainingProgram = t.viewById(FeedbackSystemUI.scanner.nextLong());
				if(trainingProgram==null)
					throw new userException();
				System.out.println("Enter your FeedBack as per below ratings");
				System.out.println("5-Excellent: �Ideal way of doing it�\r\n" + 
						"4-Good: �No pain areas or concern but could have been better�\r\n" + 
						"3-Average: �There are concerns but not significant�\r\n" + 
						"2-Below Average: �Needs improvement and is salvageable�\r\n" + 
						"1-Poor: �This way of doing things must change�\n");

				System.out.println("Presentation and communication skills of Faculty");
				int FB_prs_comm = FeedbackSystemUI.scanner.nextInt();

				System.out.println("Ability to clarify doubts and explain difficult points");
				int FB_clrfy_dbts = FeedbackSystemUI.scanner.nextInt();

				System.out.println("Time management in completing the contents");
				int FB_TM = FeedbackSystemUI.scanner.nextInt();

				System.out.println("Handout provided(Student Guide");
				int FB_Hnd_out = FeedbackSystemUI.scanner.nextInt();

				System.out.println("Hardware, software and network availability");
				int FB_Hw_Sw_Ntwrk = FeedbackSystemUI.scanner.nextInt();
				FeedbackSystemUI.scanner.nextLine();

				System.out.println("Enter comments if Any");
				String comments = FeedbackSystemUI.scanner.nextLine();

				System.out.println("Enter Suggestions if Any");
				String suggestions = FeedbackSystemUI.scanner.nextLine();

				feed.setFeedbackId(fbId);
				feed.setParticipant(emp);
				feed.setTrainingProgram(trainingProgram);
				feed.setFB_prs_comm(FB_prs_comm);
				feed.setFB_clrfy_dbts(FB_clrfy_dbts);
				feed.setFB_TM(FB_TM);
				feed.setFB_Hnd_out(FB_Hnd_out);
				feed.setFB_Hw_Sw_Ntwrk(FB_Hw_Sw_Ntwrk);
				feed.setComments(comments);
				feed.setSuggestion(suggestions);
				Feedback fb=fservice.giveFeedback(feed);
				System.out.println(fb);
				System.out.println(" To LogOut Enter 1:");
				int a=FeedbackSystemUI.scanner.nextInt();
				if(a==1)
				{
					FeedbackSystemUI.login();
				}
			}
			
			}
			catch (InputMismatchException e) {
			System.out.println("Invalid Input");
			FeedbackSystemUI.scanner.nextLine();
			}
		
			
			catch(userException exp)
			{
				System.out.println("Invalid ID");
				show();
				}

		}

	

}
