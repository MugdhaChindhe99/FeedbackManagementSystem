package com.cg.feedback.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cg.feedback.model.Employee;
import com.cg.feedback.model.Skill;
import com.cg.feedback.model.TrainingProgram;

public class EmployeeDaoImpl implements EmployeeDao {

	private static Map<Long, Employee> employee = new HashMap<Long, Employee>();
	// static Store store=null;

	public Employee login(long empId, String password) {
		Employee e;
		if ((e = employee.get(empId)) != null) {
			if (e.getPassword().equals(password)) {
				System.out.println("Login Successfully !!!");
				return e;
			} else
				System.out.println("Invalid password");
		} else
			System.out.println("Invalid userId");

		return null;
	}

	public EmployeeDaoImpl() {
		employee.put((long) 1001, new Employee(1001, "Mayur", "1234", "Admin"));
		employee.put((long) 1002, new Employee(1002, "Harshal", "0000", "Coordinator"));
		employee.put((long) 1003, new Employee(1003, "Abhinav", "0000", "Participant"));
	}

	public List<Employee> findAll() throws Exception {

		List<Employee> emp = new ArrayList<Employee>(employee.values());
		return emp;
	}


	public void addEmployee() throws Exception {
//	employee.put((long) 1001, new Employee(1001, "Mayur", "1234", "Admin",new Skill(1111,"Java"),new TrainingProgram(11,new CourseMaster(101,"JAVA AWS",60),LocalDate.of(2019,12,15),LocalDate.of(2020,02, 10),5,) ));
		employee.put((long) 1001, new Employee(1001, "Mayur", "1234", "Admin"));
	employee.put((long) 1002, new Employee(1002, "Harshal", "0000", "Coordinator"));
	employee.put((long) 1003, new Employee(1003, "Abhinav", "0000", "Participant"));
	
//		employee.put((long) 1002, new Employee(1002, "Harshal", "1234", "Coordinator"));
//		employee.put((long) 1003, new Employee(1003, "Jay", "1234", "Participant"));
//		employee.put((long) 1004, new Employee(1004, "Hetansh", "1234", "Participant"));
//		employee.put((long) 1005, new Employee(1005, "Siddhant", "1234", "Participant"));
//		employee.put((long) 1006, new Employee(1006, "Salil", "1234", "Participant"));
//		employee.put((long) 1007, new Employee(1007, "Vrushali", "1234", "Participant"));
//		employee.put((long) 1008, new Employee(1008, "Sanket", "1234", "Participant"));
//		employee.put((long) 1009, new Employee(1009, "Ketaki", "1234", "Participant"));
//		employee.put((long) 1010, new Employee(1010, "Rutuja", "1234", "Participant"));
//		employee.put((long) 1011, new Employee(1011, "Himali", "1234", "Participant"));
//		employee.put((long) 1012, new Employee(1012, "Mohit", "1234", "Participant"));

	}

	public Employee findById(long empId) throws Exception {
		return employee.get(empId);

	}

	public String updateEmployee(Employee empl) throws Exception {
		Employee e=employee.replace(empl.getEmployeeId(), empl);
		if(employee.get(e.getEmployeeId()) != null)return "updated";
		else return "Failed";
	}

	public Employee find(long empId) throws Exception {
		return employee.get(empId);
	}

	@Override
	public Employee addEmployee(Employee empl) {
		employee.put(empl.getEmployeeId(), empl);
		return empl;
	}

	@Override
	public Employee password(long pass) {
			return employee.get(pass);
		
	}
}
