package com.cg.feedback.service;

import java.util.List;

import com.cg.feedback.model.Employee;

public interface EmployeeService {

	
	Employee login(long empId, String password);

	public List<Employee> findAll() throws Exception;

	public void addEmployee() throws Exception;

	public Employee find(long empId) throws Exception;

	public String updateEmployee(Employee empl) throws Exception;

	public Employee findById(long empId) throws Exception;

	Employee addEmployee(Employee empl);
	
	public Employee password(long id);
	String namePattern = "[A-Za-z ]{3,}";
	String idPattern="[7-9]{1}[0-9]{4}";
	String passPattern="[0-9]{4}";
	
	static boolean validateName(String name)
	{
		return name.matches(namePattern);
	}
	
	static boolean validatePassword(String pass)
	{
		return pass.matches(passPattern);
	}
	
	static boolean validateIdPattern(String id)
	{
		return id.matches(idPattern);
	}
	
//	static boolean validateId(long id)
//	{
//		
//	}

}
