package com.cg.feedback.dao;

import java.util.List;

import com.cg.feedback.exception.FeedbackException;
import com.cg.feedback.model.Skill;

public interface SkillDao {

	
	Skill addSkills(Skill skill);// throws FeedbackException, Exception;
	List<Skill> findAll();
	Skill findById(long empId);
}
