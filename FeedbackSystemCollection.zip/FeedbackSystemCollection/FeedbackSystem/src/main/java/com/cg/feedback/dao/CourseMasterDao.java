package com.cg.feedback.dao;

import java.util.List;

import com.cg.feedback.model.CourseMaster;

public interface CourseMasterDao {
	
	CourseMaster addCourse(CourseMaster c);
	CourseMaster updateCourse(CourseMaster c);
	List<CourseMaster> findAll();
	CourseMaster findById(long courseId);
	CourseMaster getCourse(long cid);
		
		
}
