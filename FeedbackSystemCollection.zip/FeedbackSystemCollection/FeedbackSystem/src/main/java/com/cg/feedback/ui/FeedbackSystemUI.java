package com.cg.feedback.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

//import com.cg.feedback.exception.InvalidExceptionException;
import com.cg.feedback.exception.InvalidLoginException;
import com.cg.feedback.model.Employee;
import com.cg.feedback.service.EmployeeService;
import com.cg.feedback.service.EmployeeServiceImpl;

public class FeedbackSystemUI {

	public static Scanner scanner = new Scanner(System.in);

	public static void main(String args[]) throws Exception {
		System.out.println("Welcome to FeedBack Management System!!");
		System.out.println("Enter your Credentials : ");

		login();
	}

	public static void login() throws Exception {
		EmployeeService eservice = new EmployeeServiceImpl();
		eservice.addEmployee();
do {
		try {
		System.out.println("Enter UserId(Same as Employee Id:");
		long id = scanner.nextLong();
		//if(EmployeeService.idPattern(id))
		scanner.nextLine();
		
		Employee emp = eservice.find(id);
		if(emp==null) {
			throw new InvalidLoginException();
		}
			System.out.println("Enter Password:");
			String pass = scanner.nextLine();
			// Employee pass1 = userfetch.password(id);
			if (emp.getPassword().equals(pass)) {
				System.out.println("Logged In Successfully");
			}
			else {
				throw new InvalidLoginException();
			}
				String role = emp.getRole();
				if (role.equalsIgnoreCase("Admin")) {
					Admin admin = new Admin();
					admin.show();

				} else if (role.equalsIgnoreCase("coordinator")) {
					Coordinator coordinator = new Coordinator();
					coordinator.show();
				} else if (role.equalsIgnoreCase("participant")) {
					Participant participant = new Participant();
					participant.show();
				}
			}
		
		catch(InvalidLoginException exp)
		{
			System.out.println("Please Enter valid login details");
			login();
		}
		catch(InputMismatchException e)
		{
			System.out.println("Invalid ID");
		}
		scanner.nextLine();
}while(true);
//			
//			else {
//				System.out.println("Wrong password..");
//				login();
//			}
//		} else {
//			System.out.println("Check User Id");
//		}
	}
}
