package com.cg.feedback.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.feedback.exception.FeedbackException;
import com.cg.feedback.model.CourseMaster;
import com.cg.feedback.model.TrainingProgram;

public class TrainingProgramDaoImpl implements TrainingProgramDao {

	private Map<Long, TrainingProgram> trainingProgram;

	public TrainingProgramDaoImpl() {
		trainingProgram=new HashMap<Long, TrainingProgram>();
	}

	public List<TrainingProgram> view() throws FeedbackException {
		List<TrainingProgram> training = new ArrayList<TrainingProgram>(trainingProgram.values());
		return training;
	}

	public TrainingProgram viewById(long trainingProgramId) throws FeedbackException {

		return trainingProgram.get(trainingProgramId);

	}

	public TrainingProgram addTrainingProgram(long trainingProgramId, TrainingProgram tp) throws FeedbackException {
		
		trainingProgram.put(trainingProgramId, tp);

//		for (Long map : trainingProgram.keySet()) {
//			System.out.println(map + " : " + trainingProgram.get(map));
		//}
		return tp;
	}

	public TrainingProgram update(TrainingProgram tp) {
		trainingProgram.replace(tp.getTrainingProgramId(),tp);
				
		return tp;
	}

	@Override
	public List<TrainingProgram> findAll() {
		List<TrainingProgram> tin = new ArrayList<TrainingProgram>(trainingProgram.values());
		return tin;

	}

}
