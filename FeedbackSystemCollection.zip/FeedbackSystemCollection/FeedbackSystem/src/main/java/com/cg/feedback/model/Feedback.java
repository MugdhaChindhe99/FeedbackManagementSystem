 package com.cg.feedback.model;

import java.io.Serializable;

/**
 * Includes the details of the feedback given by participant
 * @author Mayur M
 *
 */

public class Feedback implements Serializable{
	
	@Override
	public String toString() {
		return "Feedback [feedbackId=" + feedbackId + ", participant=" + participant + ", trainingProgram="
				+ trainingProgram + ", FB_prs_comm=" + FB_prs_comm + ", FB_clrfy_dbts=" + FB_clrfy_dbts + ", FB_TM="
				+ FB_TM + ", FB_Hnd_out=" + FB_Hnd_out + ", FB_Hw_Sw_Ntwrk=" + FB_Hw_Sw_Ntwrk + ", comments=" + comments
				+ ", suggestion=" + suggestion + "]";
	}
	private long feedbackId;
	private Employee participant;
	private TrainingProgram trainingProgram;
	private int FB_prs_comm;
	private int FB_clrfy_dbts;
	private int FB_TM;
	private int FB_Hnd_out;
	private int FB_Hw_Sw_Ntwrk;
	private String comments;
	private String suggestion;
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Feedback(long feedbackId, Employee participant, TrainingProgram trainingProgram, int fB_prs_comm,
			int fB_clrfy_dbts, int fB_TM, int fB_Hnd_out, int fB_Hw_Sw_Ntwrk, String comments, String suggestion) {
		super();
		this.feedbackId = feedbackId;
		this.participant = participant;
		this.trainingProgram = trainingProgram;
		FB_prs_comm = fB_prs_comm;
		FB_clrfy_dbts = fB_clrfy_dbts;
		FB_TM = fB_TM;
		FB_Hnd_out = fB_Hnd_out;
		FB_Hw_Sw_Ntwrk = fB_Hw_Sw_Ntwrk;
		this.comments = comments;
		this.suggestion = suggestion;
	}
	public long getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(long feedbackId) {
		this.feedbackId = feedbackId;
	}
	public Employee getParticipant() {
		return participant;
	}
	public void setParticipant(Employee participant) {
		this.participant = participant;
	}
	public TrainingProgram getTrainingProgram() {
		return trainingProgram;
	}
	public void setTrainingProgram(TrainingProgram trainingProgram) {
		this.trainingProgram = trainingProgram;
	}
	public int getFB_prs_comm() {
		return FB_prs_comm;
	}
	public void setFB_prs_comm(int fB_prs_comm) {
		FB_prs_comm = fB_prs_comm;
	}
	public int getFB_clrfy_dbts() {
		return FB_clrfy_dbts;
	}
	public void setFB_clrfy_dbts(int fB_clrfy_dbts) {
		FB_clrfy_dbts = fB_clrfy_dbts;
	}
	public int getFB_TM() {
		return FB_TM;
	}
	public void setFB_TM(int fB_TM) {
		FB_TM = fB_TM;
	}
	public int getFB_Hnd_out() {
		return FB_Hnd_out;
	}
	public void setFB_Hnd_out(int fB_Hnd_out) {
		FB_Hnd_out = fB_Hnd_out;
	}
	public int getFB_Hw_Sw_Ntwrk() {
		return FB_Hw_Sw_Ntwrk;
	}
	public void setFB_Hw_Sw_Ntwrk(int fB_Hw_Sw_Ntwrk) {
		FB_Hw_Sw_Ntwrk = fB_Hw_Sw_Ntwrk;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestion() {
		return suggestion;
	}
	public void setSuggestion(String suggestion) {
		this.suggestion = suggestion;
	}

	
	
}