package com.cg.feedback.service;

import java.util.List;

import com.cg.feedback.dao.TrainingProgramDao;
import com.cg.feedback.dao.TrainingProgramDaoImpl;
import com.cg.feedback.exception.FeedbackException;
import com.cg.feedback.model.TrainingProgram;

public class TrainingProgramServiceImpl implements TrainingProgramService {

	private static TrainingProgramService trainingProgram=null;
	TrainingProgramDao dao;
	public TrainingProgramServiceImpl() {
		// TODO Auto-generated constructor stub
		dao = new TrainingProgramDaoImpl();
	}
	public static TrainingProgramService getTrainingProgramServiceImpl()
	{
		if(trainingProgram==null)
		{
			trainingProgram=new TrainingProgramServiceImpl();
		}
		return trainingProgram;
	}

	@Override
	public List<TrainingProgram> view() throws FeedbackException {
		List<TrainingProgram> ls = (List<TrainingProgram>) dao.view();
		return ls;
	}

	@Override
	public TrainingProgram viewById(long trainingProgramId) throws FeedbackException {
		return dao.viewById(trainingProgramId);
	}

	@Override
	public TrainingProgram addTrainingProgram(long trainingProgramId, TrainingProgram tp) throws FeedbackException {
		// TODO Auto-generated method stub

		return dao.addTrainingProgram(trainingProgramId, tp);
	}

	@Override
	public TrainingProgram update(TrainingProgram tp) {
		return dao.update(tp);
		
	}

	@Override
	public List<TrainingProgram> findAll() {
		return dao.findAll();
	}

}
