package com.cg.feedback.service;

import java.util.List;

import com.cg.feedback.dao.CourseMasterDao;
import com.cg.feedback.dao.CourseMasterDaoImpl;
import com.cg.feedback.model.CourseMaster;

public class CourseServiceImpl implements CourseService {

	private static CourseService courseService = null;
	private CourseMasterDao dao;

	private CourseServiceImpl() {
		dao = new CourseMasterDaoImpl();

	}

	public static CourseService getCourseServiceImpl() {
		if (courseService == null) {
			courseService = new CourseServiceImpl();
		}
		return courseService;
	}

	public CourseMaster addCourse(CourseMaster c) {

		CourseMaster courseLocal = dao.addCourse(c);
		if (courseLocal != null)
			return courseLocal;
		else
			return null;
	}

	public CourseMaster updateCourse(CourseMaster c) {

		CourseMaster courseLocal = dao.addCourse(c);
		if (courseLocal != null)
			return courseLocal;
		else
			return null;
	}

	public List<CourseMaster> findAll() {

		return dao.findAll();

	}

	public CourseMaster findById(long courseId) {

		return dao.findById(courseId);
	}

	@Override
	public CourseMaster getCourse(long cid) {
		// TODO Auto-generated method stub
		return dao.getCourse(cid);
	}

}
