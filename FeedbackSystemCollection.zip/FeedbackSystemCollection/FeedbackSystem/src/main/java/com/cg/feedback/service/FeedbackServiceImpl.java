package com.cg.feedback.service;

import java.util.List;

import com.cg.feedback.dao.FeedbackDao;
import com.cg.feedback.dao.FeedbackDaoImpl;
import com.cg.feedback.exception.FeedbackException;
import com.cg.feedback.model.Feedback;

public class FeedbackServiceImpl implements FeedbackService {

	FeedbackDao dao;
	 public FeedbackServiceImpl() 
	 {
		 try {
			dao=new FeedbackDaoImpl();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }

	public Feedback giveFeedback(Feedback fb) throws Exception {
		return dao.giveFeedback(fb);
		

	}

	public List<Feedback> showFeedbackReport() throws FeedbackException {
		
		return dao.showFeedbackReport();
	}

	@Override
	public Feedback findById(long iD) {
		return dao.findById(iD);
		
	}


}
