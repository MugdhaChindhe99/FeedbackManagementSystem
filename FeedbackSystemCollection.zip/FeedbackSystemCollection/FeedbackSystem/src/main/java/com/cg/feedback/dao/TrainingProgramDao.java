package com.cg.feedback.dao;

import java.util.List;

import com.cg.feedback.exception.FeedbackException;
import com.cg.feedback.model.TrainingProgram;

public interface TrainingProgramDao {

		
			List<TrainingProgram> view() throws FeedbackException;
			TrainingProgram viewById(long trainingProgramId) throws FeedbackException;
			TrainingProgram addTrainingProgram(long trainingProgramId,TrainingProgram tp) throws FeedbackException;
			TrainingProgram update(TrainingProgram tp) ;
			List<TrainingProgram> findAll();


}