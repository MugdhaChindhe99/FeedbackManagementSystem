package com.cg.feedback.exception;

public class viewByEmployeeException extends Exception {

	@Override
	public String toString() {
		return "viewByEmployeeException []";
	}

	public viewByEmployeeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public viewByEmployeeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
