package com.cg.feedback.service;

import java.util.List;
import java.util.Random;

import com.cg.feedback.dao.EmployeeDao;
import com.cg.feedback.dao.EmployeeDaoImpl;
import com.cg.feedback.exception.EmployeeNotFoundException;
import com.cg.feedback.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeDao edao;

	public EmployeeServiceImpl() {
		try {
			edao = new EmployeeDaoImpl();
		} catch (Exception e) {

		}
	}

	public Employee login(long empId, String password) {
		return edao.login(empId, password);

	}

	public List<Employee> findAll() throws Exception {
		List<Employee> ls = (List<Employee>) edao.findAll();
		if (ls != null)
			return ls;
		else
			throw new EmployeeNotFoundException("No Records Found");
	}

	public void addEmployee() throws Exception {

		edao.addEmployee();

	}

	private int generateEmpId() {
		Random tmpId = new Random();
		return tmpId.nextInt(1000) * 395;

	} 
	public Employee findById(long empId) throws Exception {
		return edao.findById(empId);

	}

	public String updateEmployee(Employee empl) throws Exception {
		String result = edao.updateEmployee(empl);
		return result;
	}

	public Employee find(long empId) throws Exception {
		return edao.find(empId);
	}
	
	public Employee password(long pass)
	{
		return edao.password(pass);
	}

	@Override
	public Employee addEmployee(Employee empl) {
		return edao.addEmployee(empl);
	}
}
