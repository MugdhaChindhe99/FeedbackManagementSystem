package com.cg.feedback.model;

import java.io.Serializable;
import java.util.Set;

/**
 * includes employee details,employee Id will be generated automatically
 * @author Mayur M
 *@version 1.0
 */
public class Employee implements Serializable{

	private long employeeId;
	private String employeeName;
	private String password;
	private String role;
	private Set<Skill> skills;
	private Set<TrainingProgram> trainingProgramParticipated;
	CourseMaster cr;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Employee(long employeeId, String employeeName, String password, String role) {
	
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.password = password;
		this.role = role;
	}



	public Employee(long employeeId, String employeeName, String password, String role, Set<Skill> skills,
			 Set<TrainingProgram> trainingProgramParticipated) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.password = password;
		this.role = role;
		this.skills = skills;
		//this.trainingProgramConducted = trainingProgramConducted;
		this.trainingProgramParticipated = trainingProgramParticipated;
	}

	public long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getPassword() {
		
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Set<Skill> getSkills() {
		return skills;
	}

	public void setSkills(Set<Skill> skills) {
		this.skills = skills;
	}

	/*
	 * public Set<TrainingProgram> getTrainingProgramConducted() { return
	 * trainingProgramConducted; }
	 * 
	 * public void setTrainingProgramConducted(Set<TrainingProgram>
	 * trainingProgramConducted) { this.trainingProgramConducted =
	 * trainingProgramConducted; }
	 */
	public Set<TrainingProgram> getTrainingProgramParticipated() {
		return trainingProgramParticipated;
	}

	public void setTrainingProgramParticipated(Set<TrainingProgram> trainingProgramParticipated) {
		this.trainingProgramParticipated = trainingProgramParticipated;
	}
	public String toString() {
		return "empid:"+this.employeeId+"\nemp Name :"+this.employeeName+"\nemp password  "+this.password+"\nemp role"+this.role;
	}

}
