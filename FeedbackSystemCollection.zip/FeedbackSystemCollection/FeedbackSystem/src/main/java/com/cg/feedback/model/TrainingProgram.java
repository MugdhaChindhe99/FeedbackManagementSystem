package com.cg.feedback.model;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public class TrainingProgram implements Comparable<TrainingProgram> {
	private long trainingProgramId;
	private CourseMaster course;
	private LocalDate startDate;
	private LocalDate endDate;
	private long hourPerDay;
	private Employee trainer;
	private List<Employee> participant;
	//private List<Feedback> feedback;

	public TrainingProgram() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TrainingProgram(long trainingProgramId, CourseMaster course, LocalDate startDate, LocalDate endDate,
			long hourPerDay, Employee trainer, List<Employee> participant/* , List<Feedback> feedback */) {
		super();
		this.trainingProgramId = trainingProgramId;
		this.course = course;
		this.startDate = startDate;
		this.endDate = endDate;
		this.hourPerDay = hourPerDay;
		this.trainer = trainer;
		this.participant = participant;
	//	this.feedback = feedback;
	}

	public long getTrainingProgramId() {
		return trainingProgramId;
	}

	public void setTrainingProgramId(long trainingProgramId) {
		this.trainingProgramId = trainingProgramId;
	}

	public CourseMaster getCourse() {
		return course;
	}

	public void setCourse(CourseMaster course) {
		this.course = course;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public long getHourPerDay() {
		return hourPerDay;
	}

	public void setHourPerDay(long hourPerDay) {
		this.hourPerDay = hourPerDay;
	}

	public Employee getTrainer() {
		return trainer;
	}

	public void setTrainer(Employee trainer) {
		this.trainer = trainer;
	}

	public List<Employee> getParticipant() {
		return participant;
	}

	public void setParticipant(List<Employee> participant) {
		this.participant = participant;
	}

	@Override
	public String toString() {
		return "TrainingProgram [trainingProgramId=" + trainingProgramId + ", course=" + course + ", startDate="
				+ startDate + ", endDate=" + endDate + ", hourPerDay=" + hourPerDay + ", trainer=" + trainer
				+ ", participant=" + participant + "]";
	}

	@Override
	public int compareTo(TrainingProgram o) {
		// TODO Auto-generated method stub
		return (int)this.trainingProgramId-(int)o.trainingProgramId;
	}

	/*
	 * public List<Feedback> getFeedback() { return feedback; }
	 * 
	 * public void setFeedback(List<Feedback> feedback) { this.feedback = feedback;
	 * }
	 */

	

	
}
