package com.cg.feedback.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

import org.junit.jupiter.api.Test;

import com.cg.feedback.model.Employee;
import com.cg.feedback.model.Skill;
import com.cg.feedback.model.TrainingProgram;
import com.cg.feedback.service.EmployeeService;
import com.cg.feedback.service.EmployeeServiceImpl;

class EmployeeTest {

	private EmployeeService eservice;
	private Set<Skill> skills;
	private Set<TrainingProgram> trainingProgramParticipated;
	
	@Test
	public void testValidAddEmployee() {
		eservice=new EmployeeServiceImpl();
		Employee e=new Employee(9001,"Aditya","1234","Developer");
		assertEquals(e,eservice.addEmployee(e));
	}
	@Test
	public void testInvalidAddEmployee() {
		eservice=new EmployeeServiceImpl();
		Employee e=new Employee();
		assertNotNull(eservice.addEmployee(e));
	}
	
	@Test
	public void testValidUpdate() {
		eservice=new EmployeeServiceImpl();
		Employee e=new Employee(1001,"Aditya","1234","Developer");
		try {
			assertEquals("updated",eservice.updateEmployee(e));
		} catch (Exception e1) {
			System.out.println("Error detected");
		}
	}
	
	@Test
	public void testInvalidUpdate() {
		eservice=new EmployeeServiceImpl();
		Employee e=new Employee(9009,"Aditya","1234","Developer");
		try {
			assertNotEquals("updated",eservice.updateEmployee(e));
		} catch (Exception e1) {
			System.out.println("Error detected");
		}
	}
	
	@Test
	public void testValidSearch() {
		eservice=new EmployeeServiceImpl();
		long empId=1001;
		try {
			assertNotNull(eservice.findById(empId));
		} catch (Exception e) {
			System.out.println("Error in valid search");
		}
	}
	
	@Test
	public void testInValidSearch() {
		eservice=new EmployeeServiceImpl();
		long empId=9001;
		try {
			assertNull(eservice.findById(empId));
		} catch (Exception e) {
			System.out.println("Error in valid search");
		}
	}

	@Test
	public void testValidSearchAll() {
		eservice=new EmployeeServiceImpl();
		try {
			assertNotNull(eservice.findAll());
		} catch (Exception e) {
			System.out.println("Error in valid search");
		}
	}
	
	@Test
	public void validLogin() throws Exception {
		eservice=new EmployeeServiceImpl();
		Employee tmpEmp =eservice.findById(1001);
		assertEquals(tmpEmp,eservice.login(1001, "1234"));
	}
	
	@Test
	public void invalidLogin() throws Exception{
		eservice=new EmployeeServiceImpl();
		assertNull(eservice.login(1005, "ae123"));
	}
}
