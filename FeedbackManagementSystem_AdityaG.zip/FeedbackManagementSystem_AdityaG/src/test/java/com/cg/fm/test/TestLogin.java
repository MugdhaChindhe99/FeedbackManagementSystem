package com.cg.fm.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

import com.cg.fm.exception.EmployeeNotFoundException;
import com.cg.fm.model.Employee;
import com.cg.fm.service.EmployeeService;
import com.cg.fm.service.EmployeeServiceImpl;

public class TestLogin {
	EmployeeService employeeSevice;
	@Before
	public void startTest() throws EmployeeNotFoundException {
	employeeSevice=new EmployeeServiceImpl();
	}
	
	@Test
	public void validLogin() throws Exception {
		Employee tmpEmp =employeeSevice.findById(101);
		assertEquals(tmpEmp,employeeSevice.login(101, "a123"));
	}
	
	@Test
	public void invalidLogin() throws Exception{
		assertNull(employeeSevice.login(105, "ae123"));
	}
}
