package com.cg.fm.exception;
/**
 * Skill exception that is called when Exception is occured during skill related operations
 * @author Aditya Ghogale
 *
 */
public class SkillException extends Exception {

	private String message; //to store message from parameter

	public SkillException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String toString() {
		return "SkillException message=" + message;
	}
	
}
