package com.cg.fm.model;

import java.io.Serializable;

/**
 * This is a course class with fields to save information about course
 * 
 * @author Aditya Ghogale
 *
 */
public class Course implements Serializable{

	
	private long courseId;
	private String courseName;
	private long duration;
	private Skill skill;	
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Course(long courseId, String courseName, long duration, Skill skill) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.duration = duration;
		this.skill = skill;
	}
	public long getCourseId() {
		return courseId;
	}
	public void setCourseId(long courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public long getDuration() {
		return duration;
	}
	public void setDuration(long duration) {
		this.duration = duration;
	}
	public Skill getSkill() {
		return skill;
	}
	public void setSkill(Skill skill) {
		this.skill = skill;
	}
	@Override
	public String toString() {
		return "\nCourseDetails \ncourseId=" + courseId + "\t courseName=" + courseName + "\n duration=" + duration + "\t skill="
				+ skill + "\n";
	}
	
	
	
	
}
