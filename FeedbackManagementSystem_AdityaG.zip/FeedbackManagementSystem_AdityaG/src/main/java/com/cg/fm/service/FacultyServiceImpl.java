package com.cg.fm.service;

public class FacultyServiceImpl implements FacultyService {

}
