package com.cg.fm.exception;

public class FeedbackException extends Exception {

	public FeedbackException(String string) {
		// TODO Auto-generated constructor stub
	}

}
