package com.cg.fm.service;

import java.util.List;

import com.cg.fm.exception.SkillException;
import com.cg.fm.model.Skill;

/**
 * Skill service interface to connect with DAO
 * 
 * @author Aditya Ghogale
 *
 */
public interface SkillService {
	Skill addSkills(Skill skill) throws SkillException;

	List<Skill> findAll();

	Skill findById(long skillId);
}
