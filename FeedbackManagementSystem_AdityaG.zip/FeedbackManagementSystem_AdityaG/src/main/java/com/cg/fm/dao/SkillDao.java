package com.cg.fm.dao;

import java.util.List;

import com.cg.fm.exception.SkillException;
import com.cg.fm.model.Skill;

public interface SkillDao {

	Skill addSkills(Skill skill) throws SkillException;

	List<Skill> findAll();

	Skill findById(long skillId);
}
