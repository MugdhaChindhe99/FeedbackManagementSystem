package com.cg.fm.model;

import java.io.Serializable;

public class Skill implements Serializable{

	private long skillId;
	private String title;
	
	public Skill(long skillId, String title) {
		super();
		this.skillId = skillId;
		this.title = title;
	}
	public Skill() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getSkillId() {
		return skillId;
	}
	public void setSkillId(long skillId) {
		this.skillId = skillId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public String toString() {
		return "\nSkill \nskillId=" + skillId + "\t title=" + title+"\n";
	}
}
