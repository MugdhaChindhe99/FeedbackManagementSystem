package com.cg.fm.dao;

import com.cg.fm.model.Employee;

public class skillDaoAddSkill {

	public static void main(String[] args) throws Exception {

		Employee e = new Employee();
		Employee e1= new Employee();
		Employee e2= new Employee();
		EmployeeDao edao = new EmployeeDaoImpl();
		e.setEmployeeId(101);
		e.setEmployeeName("Adi");
		e.setPassword("a123");
		e.setRole("admin");
		edao.addEmployee(101, e);
		e1.setEmployeeId(102);
		e1.setEmployeeName("zoro");
		e1.setPassword("z123");
		e1.setRole("coordinator");
		edao.addEmployee(102, e1);
		e2.setEmployeeId(103);
		e2.setEmployeeName("luffy");
		e2.setPassword("l123");
		e2.setRole("participant");
		edao.addEmployee(103, e2);
		System.out.println("done");

	}

}
