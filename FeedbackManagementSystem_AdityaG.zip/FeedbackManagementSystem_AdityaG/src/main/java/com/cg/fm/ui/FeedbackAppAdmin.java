package com.cg.fm.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.fm.exception.CourseException;
import com.cg.fm.exception.FeedbackException;
import com.cg.fm.exception.SkillException;
import com.cg.fm.model.Course;
import com.cg.fm.model.Employee;
import com.cg.fm.model.Feedback;
import com.cg.fm.model.Skill;
import com.cg.fm.model.TrainingProgram;
import com.cg.fm.service.CourseService;
import com.cg.fm.service.CourseServiceImpl;
import com.cg.fm.service.EmployeeService;
import com.cg.fm.service.EmployeeServiceImpl;
import com.cg.fm.service.FeedbackService;
import com.cg.fm.service.FeedbackServiceImpl;
import com.cg.fm.service.SkillService;
import com.cg.fm.service.SkillServiceImpl;
import com.cg.fm.service.TrainingProgramService;
import com.cg.fm.service.TrainingProgramServiceImpl;

/**
 * FeedbackAppAdmin UI for calling functionalities of Admin
 * 
 * @author Aditya Ghogale
 *
 */
public class FeedbackAppAdmin {

	public static Scanner console = new Scanner(System.in);

	public static void adminPanel() throws Exception {

		do {
			// Display list of admin functionalities
			System.out.println("Welcome to Admin Panel");
			System.out.println("Select operation\n1-Add Employee \n2-Update Employee \n3-Find Employee By Id");
			System.out.println("4-All Employees \n5-Add Course \n6-Update Course");
			System.out.println("7-Find Course By Id \n8-All Courses \n9-Feedback Report");
			System.out.println("10-Logout");
			// accept choice from user and call specific method
			switch (console.nextInt()) {
			// create new employee
			case 1:
				addNewEmployee();
				break;
			case 2:
				updateExistingEmployee();
				break;
			case 3:
				viewEmployeById();
				break;
			case 4:
				listAllEmployee();
				break;
			case 5:
				addNewCourse();
				break;
			case 6:
				updateCourse();
				break;
			case 7:
				findCourseById();
				break;
			case 8:
				listAllCourse();
				break;
			case 9:
				listFeedback();
				break;
			case 10:
				System.out.println("Exiting Feedback System!!!!!");
				System.exit(0);
			}
		} while (true);
	}

	// Display list of feedbacks on particular course
	private static void listFeedback() throws FeedbackException {

		FeedbackService feedbackService = new FeedbackServiceImpl();

		List<Feedback> feedbacks = feedbackService.showFeedbackReport();

		feedbacks.stream().forEach(System.out::println);

	}

	// Displays list of all courses in database
	private static void listAllCourse() throws CourseException {

		CourseService courseService = new CourseServiceImpl();

		List<Course> courseList = courseService.findAll();

		for (Course crs : courseList) {
			System.out.println(crs);
		}

	}

	// Display specific course based on id
	private static void findCourseById() throws CourseException {

		CourseService courseService = new CourseServiceImpl();

		Course tmpCourse = new Course();

		long courseId;

		System.out.println("Enter course id");
		courseId = console.nextLong();
		tmpCourse = courseService.findById(courseId);
		System.out.println(tmpCourse);

	}

	// Update existing course i.e. replace existing course object with new course
	// object
	private static void updateCourse() throws CourseException, SkillException {

		// service objects
		CourseService courseService = new CourseServiceImpl();
		SkillService skillService = new SkillServiceImpl();

		// model object
		Course tmpCourse = new Course();

		System.out.println("Enter course ID");
		tmpCourse = courseService.findById(console.nextLong());
		console.nextLine();

		// local variables
		String courseName = tmpCourse.getCourseName();
		long courseId = tmpCourse.getCourseId();
		long dur = tmpCourse.getDuration();
		long tmpId = tmpCourse.getSkill().getSkillId();
		String loopV = "y";

		try {
			if (tmpCourse == null)
				throw new CourseException("Invalid Course ID");
			else {
				courseId = tmpCourse.getCourseId();
				// ask what user want to update
				do {
					System.out.println("What do you want to update  1-Name  2-Duration  3-Skill");
					switch (console.nextInt()) {
					case 1:
						console.nextLine();
						System.out.println("Enter course name");
						courseName = console.nextLine();
						break;
					case 2:
						System.out.println("Enter duration in hours");
						dur = console.nextLong();
						console.nextLine();
						break;
					case 3:
						System.out.println("Enter skill Id");
						tmpId = console.nextLong();
						console.nextLine();
						break;
					default:
						System.out.println("Wrong Choice");
					}
					System.out.println("Do you wish to continue editing y/n");
					loopV = console.next();
					console.nextLine();
				} while ("y".equalsIgnoreCase(loopV));
				tmpCourse = new Course(courseId, courseName, dur, skillService.findById(tmpId));
				courseService.updateCourse(tmpCourse);
			}
		} catch (CourseException exp) {
			System.out.println(exp);
		}

	}

	// To add new Course in database
	private static void addNewCourse() throws SkillException, CourseException {
		// local variables
		long tmpId;
		long courseId=99999;
		
		
		// model object
		Course tmpCourse = new Course();

		// Service objects
		CourseService courseService = new CourseServiceImpl();
		SkillService skillService = new SkillServiceImpl();

		// accept input form user
		
		try {
		System.out.println("Enter course ID");
		courseId = console.nextLong();
		
		}
		catch(InputMismatchException exp){
			System.out.println("Course Id can contain numeric value only. Default Id is assigned to course");
		}
		console.nextLine();
		System.out.println("Enter course name");
		String courseName = console.nextLine();
		System.out.println("Enter duration in hours");
		long dur = console.nextLong();
		System.out.println("Enter skill Id");
		tmpId = console.nextLong();

		// storing of course
		tmpCourse = new Course(courseId, courseName, dur, skillService.findById(tmpId));
		courseService.addCourse(tmpCourse);

	}

	// List of all employee in database
	private static void listAllEmployee() throws Exception {
		// Service object
		EmployeeService employeeService = new EmployeeServiceImpl();

		// List of employee to store list return by displayAll method
		List<Employee> employeeList = employeeService.displayAll();

		// to display list
		employeeList.stream().forEach(System.out::println);

	}

	// View specific employee from database using employee id
	private static void viewEmployeById() throws Exception {
		// Local variable
		long tmpId;

		// Service object
		EmployeeService employeeService = new EmployeeServiceImpl();

		// accept id from user
		System.out.println("Enter employee id");
		tmpId = console.nextInt();

		// retrieve record and save in object
		Employee ex = employeeService.findById(tmpId);
		if(ex!=null)System.out.println(ex);
		else System.out.println("No employee with such id exist");
	}

	// Update existing employee
	private static void updateExistingEmployee() throws Exception {

		// Service objects
				EmployeeService employeeService = new EmployeeServiceImpl();
				SkillService skillService = new SkillServiceImpl();
				TrainingProgramService trainingProgramService = new TrainingProgramServiceImpl();

				// local variables
				String tmpName;
				String tmpRole;
				String tmpPassword;
				String loopV = "y";

				// model objects
				Employee tmpEmployee = new Employee();
				List<Skill> skillSet;
				TrainingProgram trainingProgramConducted=new TrainingProgram();
				TrainingProgram trainingProgramParticipated=new TrainingProgram();

				// Search for employee and assign his/her attribute values as default to local
				// variables
				
				System.out.println("Enter EmployeeID of employee to update ");
				tmpEmployee = employeeService.findById(console.nextLong());
				if ( !tmpEmployee.equals(null)) {

					tmpName = tmpEmployee.getEmployeeName();
					tmpRole = tmpEmployee.getRole();
					tmpPassword = tmpEmployee.getPassword();
					skillSet = tmpEmployee.getSkills();
					trainingProgramConducted = tmpEmployee.getTrainingProgramConducted();
					trainingProgramParticipated = tmpEmployee.getTrainingProgramParticipated();

					// accept employee details
					System.out.println("What do you want to update \n1-Update Name \n2-Update Role \n3-Update Password");
					System.out.println("4-Add new Skill");

					switch (console.nextInt()) {

					case 1:// Update Name
						do {
							console.nextLine();
							System.out.println("Enter name");
							tmpName = console.nextLine();
							if (tmpName.matches(EmployeeService.namePattern))
								break;
							else
								System.out.println("Invalid Name");
						} while (true);
						break;

					case 2:// Update Role
						console.nextLine();
						System.out.println("Enter role");
						tmpRole = console.nextLine();
						break;

					case 3:// Update Password
						console.nextLine();
						System.out.println("Enter Password");
						tmpPassword = console.nextLine();
						break;

					case 4:// Add new Skills
						console.nextLine();
						System.out.println("Enter Skill Id");
						long tmpId = console.nextLong();
						Skill skl = skillService.findById(tmpId);
						skillSet.add(skl);
						break;
					}
					// set values of employee
					tmpEmployee.setEmployeeName(tmpName);
					tmpEmployee.setPassword(tmpPassword);
					tmpEmployee.setRole(tmpRole);
					tmpEmployee.setSkills(skillSet);
					employeeService.updateEmployee(tmpEmployee);
					System.out.println("Employee Record Updated");
				} else
					System.out.println("Invalid Employee ID");

	}

	// To add new Employee
	private static void addNewEmployee() throws Exception {
		// Service objects
				EmployeeService employeeService = new EmployeeServiceImpl();
				SkillService skillService = new SkillServiceImpl();
				TrainingProgramService trainingProgramService = new TrainingProgramServiceImpl();

				// local variables
				String tmpName = null;
				String tmpRole = null;
				String tmpPassword = null;
				String loopV = "y";

				// model objects
				Employee tmpEmployee = new Employee();
				List<Skill> skillSet = new ArrayList<>();
				TrainingProgram trainingProgramConducted = null;
				TrainingProgram trainingProgramParticipated = null;
				console.nextLine();
				// Accept employee details
				do {
					System.out.println("Enter name");
					tmpName = console.nextLine();
					if (tmpName.matches(EmployeeService.namePattern))
						break;
					else
						System.out.println("Invalid Name");
				} while (true);

				System.out.println("Enter role");
				tmpRole = console.nextLine();
				System.out.println("Enter Password");
				tmpPassword = console.nextLine();

				// to add list of skills
				System.out.println("Select skill you possess");
				do {
					System.out.println("1- Java\t 2- C\t 3-C++\t 4-Python\t 5-HTML\n 6-JavaScript\t 7-JQuery\t 8-Done");
					switch (console.nextInt()) {
					case 1:
						Skill sk = skillService.findById(1111);
						skillSet.add(sk);
						break;
					case 2:
						skillSet.add(skillService.findById(2222));
						break;
					case 3:
						skillSet.add(skillService.findById(3333));
						break;
					case 4:
						skillSet.add(skillService.findById(4444));
						break;
					case 5:
						skillSet.add(skillService.findById(5555));
						break;
					case 6:
						skillSet.add(skillService.findById(6666));
						break;
					case 7:
						skillSet.add(skillService.findById(7777));
						break;
					case 8:
						loopV = "n";
						break;
					}
				} while ("y".equalsIgnoreCase(loopV));

				// List of program Conducted
				System.out.println("Enter code of training program conducted (pass 1 if not conducted anything)");

				tmpEmployee.setTrainingProgramConducted(trainingProgramService.viewById(console.nextInt()));
				console.nextLine();

				// List of program participated in

				System.out.println("Enter code of training program participated(pass 1 if not participated in anything)");

				tmpEmployee.setTrainingProgramParticipated(trainingProgramService.viewById(console.nextInt()));
				console.nextLine();

				// set values in model objects
				tmpEmployee.setEmployeeName(tmpName);
				tmpEmployee.setPassword(tmpPassword);
				tmpEmployee.setRole(tmpRole);
				tmpEmployee.setSkills(skillSet);
				// tmpEmployee.setTrainingProgramConducted(trainingProgramConducted);
				// tmpEmployee.setTrainingProgramParticipated(trainingProgramParticipated);

				System.out.println("Employee added with id :" + employeeService.addEmployee(tmpEmployee).getEmployeeId());

	}
}
