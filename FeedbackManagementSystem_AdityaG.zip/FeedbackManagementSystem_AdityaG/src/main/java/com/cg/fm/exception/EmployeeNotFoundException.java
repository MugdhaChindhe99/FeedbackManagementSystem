package com.cg.fm.exception;

public class EmployeeNotFoundException extends Exception {

	private String message;

	public EmployeeNotFoundException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String toString() {
		return "EmployeeNotFoundException message=" + message;
	}
	
}
