package com.cg.fm.dao;

import java.util.List;

import com.cg.fm.exception.CourseException;
import com.cg.fm.exception.FeedbackException;
import com.cg.fm.model.Course;

/**
 * CourseDao interface with prototype of methods to perform operations with Course
 * @author Aditya Ghogale
 *
 */
public interface CourseDao {

	Course addCourse(Course course) throws CourseException;
	Course updateCourse(Course course) throws CourseException;
	List<Course> findAll();
	Course findById(long courseId);
	}
