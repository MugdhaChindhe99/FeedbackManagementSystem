package com.cg.fm.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.cg.fm.model.Course;
import com.cg.fm.model.Employee;
import com.cg.fm.model.Feedback;
import com.cg.fm.model.Skill;
import com.cg.fm.model.TrainingProgram;

public class Store implements Serializable {

	private Map<Long, Employee> employees;
	private Map<Long, Feedback> feedbacks;
	private Map<Long, Skill> skills;
	private Map<Long, Course> course;
	private Map<Long, TrainingProgram> trainingProgram;

	private static Store store;

	public static final String STORE_PATH = "ObjectStore.dat";

	private Store() {
		this.employees = new HashMap<Long, Employee>();
		this.feedbacks = new HashMap<>();
		this.skills = new HashMap<>();
		this.course = new HashMap<>();
		this.trainingProgram = new HashMap<>();
	}

	public Map<Long, Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(Map<Long, Employee> employees) {
		this.employees = employees;
	}

	public Map<Long, Feedback> getFeedbacks() {
		return feedbacks;
	}

	public void setFeedbacks(Map<Long, Feedback> feedbacks) {
		this.feedbacks = feedbacks;
	}

	public Map<Long, Skill> getSkills() {
		return skills;
	}

	public void setSkills(Map<Long, Skill> skills) {
		this.skills = skills;
	}

	public Map<Long, Course> getCourse() {
		return course;
	}

	public void setCourse(Map<Long, Course> course) {
		this.course = course;
	}

	public Map<Long, TrainingProgram> getTrainingProgram() {
		return trainingProgram;
	}

	public void setTrainingProgram(Map<Long, TrainingProgram> trainingProgram) {
		this.trainingProgram = trainingProgram;
	}

	public static synchronized Store getInstatnce() throws Exception {

		if (null == store) {
			File file = new File(STORE_PATH);
			if (file.exists()) {

				ObjectInputStream ois = new ObjectInputStream(new FileInputStream(STORE_PATH));
				Object obj = ois.readObject();
				if (obj instanceof Store) {
					store = (Store) obj;
					ois.close();
				}

			} else
				store = new Store();
		}
		return store;
	}

	public synchronized void Save() throws Exception {
		// write store object into object output stream
		ObjectOutputStream fos = new ObjectOutputStream(new FileOutputStream(STORE_PATH));
		fos.writeObject(store);
		System.out.println("Done");
		fos.flush();
		fos.close();

	}
}
