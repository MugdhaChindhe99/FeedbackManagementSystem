package com.cg.fm.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.fm.dao.TrainingProgramDao;
import com.cg.fm.dao.TrainingProgramDaoImpl;
import com.cg.fm.exception.TrainingProgramException;
import com.cg.fm.model.TrainingProgram;

/**
 * Body of methods of Training Program Service
 * 
 * @author Aditya Ghogale
 *
 */
public class TrainingProgramServiceImpl implements TrainingProgramService {

	private TrainingProgramDao trainingProgramDAO;
	private final String datePattern="^([0-2][0-9]||3[0-1])/(0[0-9]||1[0-2])/([0-9][0-9])?[0-9][0-9]$";
	
	public TrainingProgramServiceImpl() throws TrainingProgramException {
		trainingProgramDAO=new TrainingProgramDaoImpl();
	}

	//calls viewAll method of DAO
	@Override
	public List<TrainingProgram> viewAll() throws TrainingProgramException {
		
		return trainingProgramDAO.viewAll();
	}

	//calls viewById method of DAO
	@Override
	public TrainingProgram viewById(long trainingProgramId) throws TrainingProgramException {
		
		return trainingProgramDAO.viewById(trainingProgramId);
	}

	//calls addTrainingProgram method of DAO to add new course
	@Override
	public TrainingProgram addTrainingProgram(long trainingProgramId, TrainingProgram trainingProgram)
			throws TrainingProgramException {
	
		return trainingProgramDAO.addTrainingProgram(trainingProgramId, trainingProgram);
	}

	//calls update method of DAO to update existing method
	@Override
	public TrainingProgram update(TrainingProgram tarainingProgram) throws TrainingProgramException {
		
		return trainingProgramDAO.update(tarainingProgram);
	}

	

	@Override
	public boolean validateDate(LocalDate startDate) {
		// TODO Auto-generated method stub
		return false;
	}

}
