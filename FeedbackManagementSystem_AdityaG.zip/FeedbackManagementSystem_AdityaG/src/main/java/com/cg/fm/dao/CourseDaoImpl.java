package com.cg.fm.dao;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.cg.fm.exception.CourseException;
import com.cg.fm.exception.FeedbackException;
import com.cg.fm.model.Course;

/**
 * Contains body of methods of Course dao
 * 
 * @author Aditya Ghogale
 *
 */
public class CourseDaoImpl implements CourseDao {

	private Map<Long, Course> courses;
	private Store store;
	public CourseDaoImpl() throws Exception {
		store=Store.getInstatnce();
		courses=Store.getInstatnce().getCourse();
	}
	
	@Override
	public Course addCourse(Course course) throws CourseException {
		courses.put(course.getCourseId(),course);
		saveToFile();
		return null;
	}
	private void saveToFile() throws CourseException {
		store.setCourse(courses);
		try {
			store.Save();
		} catch (Exception e) {
			throw new CourseException("Unable to add course");
		}
		
	}
	@Override
	public Course updateCourse(Course course) throws CourseException {
		courses.put(course.getCourseId(),course);
		saveToFile();
		return course;
	}
	@Override
	public List<Course> findAll() {
		
		return (List<Course>) courses.values().stream().collect(Collectors.toList());
	}
	@Override
	public Course findById(long courseId) {
		return courses.get(courseId);
	}

	

}
