package com.cg.fm.model;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public class Employee implements Serializable{

	private long employeeId;
	private String employeeName;
	private String password;
	private String role;
	private List<Skill> skills;
	private TrainingProgram trainingProgramConducted;
	private TrainingProgram trainingProgramParticipated;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(long employeeId, String employeeName, String password, String role, List<Skill> skills,
			TrainingProgram trainingProgramConducted, TrainingProgram trainingProgramParticipated) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.password = password;
		this.role = role;
		this.skills = skills;
		this.trainingProgramConducted = trainingProgramConducted;
		this.trainingProgramParticipated = trainingProgramParticipated;
	}

	public long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public List<Skill> getSkills() {
		return skills;
	}

	public void setSkills(List<Skill> skills) {
		this.skills = skills;
	}

	public TrainingProgram getTrainingProgramConducted() {
		return trainingProgramConducted;
	}

	public void setTrainingProgramConducted(TrainingProgram trainingProgramConducted) {
		this.trainingProgramConducted = trainingProgramConducted;
	}

	public TrainingProgram getTrainingProgramParticipated() {
		return trainingProgramParticipated;
	}

	public void setTrainingProgramParticipated(TrainingProgram trainingProgramParticipated) {
		this.trainingProgramParticipated = trainingProgramParticipated;
	}
	@Override
	public String toString() {
		return "\nEmployee \nemployeeId=" + employeeId + "\t employeeName=" + employeeName + "\n password=" + password
				+ "\t role=" + role + "\n skills=" + skills + "\n trainingProgramConducted=" + trainingProgramConducted
				+ "\n trainingProgramParticipated=" + trainingProgramParticipated + "\n";
	}

}
