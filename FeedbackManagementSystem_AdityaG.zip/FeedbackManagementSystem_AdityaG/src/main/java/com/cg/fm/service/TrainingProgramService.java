package com.cg.fm.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.fm.exception.TrainingProgramException;
import com.cg.fm.model.TrainingProgram;

/**
 * Training Program Service interface with methods to provide link between UI and DAO
 * 
 * @author Aditya Ghogale
 *
 */
public interface TrainingProgramService {
	List<TrainingProgram> viewAll() throws TrainingProgramException;

	TrainingProgram viewById(long trainingProgramId) throws TrainingProgramException;

	TrainingProgram addTrainingProgram(long trainingProgramId, TrainingProgram trainingProgram)
			throws TrainingProgramException;

	TrainingProgram update(TrainingProgram tarainingProgram) throws TrainingProgramException;

	boolean validateDate(LocalDate startDate);

}
