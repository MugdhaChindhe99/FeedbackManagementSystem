package com.cg.fm.model;

import java.io.Serializable;

public class Feedback implements Serializable {
	private long feedbackId;
	private Employee participant;
	private TrainingProgram trainingProgram;
	private int fbPrsComm;
	private int fbClrfyDbts;
	private int fbTM;
	private int fbHndOut;
	private int fbHwSwNtwrk;
	private String comments;
	private String suggestion;
	
	
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Feedback(long feedbackId, Employee participant, TrainingProgram trainingProgram, int fbPrsComm,
			int fBClrfyDbts, int fBTM, int fBHndOut, int fBHwSwNtwrk, String comments, String suggestion) {
		super();
		this.feedbackId = feedbackId;
		this.participant = participant;
		this.trainingProgram = trainingProgram;
		fbPrsComm = fbPrsComm;
		fbClrfyDbts = fBClrfyDbts;
		fbTM = fBTM;
		fbHndOut = fBHndOut;
		fbHwSwNtwrk = fBHwSwNtwrk;
		this.comments = comments;
		this.suggestion = suggestion;
	}
	public long getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(long feedbackId) {
		this.feedbackId = feedbackId;
	}
	public Employee getParticipant() {
		return participant;
	}
	public void setParticipant(Employee participant) {
		this.participant = participant;
	}
	public TrainingProgram getTrainingProgram() {
		return trainingProgram;
	}
	public void setTrainingProgram(TrainingProgram trainingProgram) {
		this.trainingProgram = trainingProgram;
	}
	public int getFB_prs_comm() {
		return fbPrsComm;
	}
	public void setFB_prs_comm(int fB_prs_comm) {
		fbPrsComm = fB_prs_comm;
	}
	public int getFB_clrfy_dbts() {
		return fbClrfyDbts;
	}
	public void setFB_clrfy_dbts(int fB_clrfy_dbts) {
		fbClrfyDbts = fB_clrfy_dbts;
	}
	public int getFB_TM() {
		return fbTM;
	}
	public void setFB_TM(int fB_TM) {
		fbTM = fB_TM;
	}
	public int getFB_Hnd_out() {
		return fbHndOut;
	}
	public void setFB_Hnd_out(int fB_Hnd_out) {
		fbHndOut = fB_Hnd_out;
	}
	public int getFB_Hw_Sw_Ntwrk() {
		return fbHwSwNtwrk;
	}
	public void setFB_Hw_Sw_Ntwrk(int fB_Hw_Sw_Ntwrk) {
		fbHwSwNtwrk = fB_Hw_Sw_Ntwrk;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestion() {
		return suggestion;
	}
	public void setSuggestion(String suggestion) {
		this.suggestion = suggestion;
	}
	@Override
	public String toString() {
		return "\nFeedBack \nfeedbackId = " + feedbackId + "\t participant = " + participant + "\n trainingProgram = "
				+ trainingProgram + " Communication = " + fbPrsComm + "\t clearify doubts = " + fbClrfyDbts + "\nTime Management = "
				+ fbTM + "\tHand Outs = " + fbHndOut + "\nHardware and Software Network = " + fbHwSwNtwrk + "\ncomments=" + comments
				+ "\n suggestion=" + suggestion;
	}



}
