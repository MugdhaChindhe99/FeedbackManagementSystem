package com.cg.fm.exception;

public class CourseException extends Exception {

	private String message;

	public CourseException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String toString() {
		return "CourseException message=" + message ;
	}
	
}
