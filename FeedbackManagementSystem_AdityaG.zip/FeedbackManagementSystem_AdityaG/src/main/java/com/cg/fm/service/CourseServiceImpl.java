package com.cg.fm.service;

import java.util.List;

import com.cg.fm.dao.CourseDao;
import com.cg.fm.dao.CourseDaoImpl;
import com.cg.fm.exception.CourseException;
import com.cg.fm.model.Course;

/**
 * CourseServiceImpl contains body of methods of Service interface
 * @author Aditya Ghogale
 *
 */
public class CourseServiceImpl implements CourseService {

	private CourseDao cdao;
	
	public CourseServiceImpl() throws CourseException{
		try {
			cdao=new CourseDaoImpl();
		} catch (Exception e) {
			throw new CourseException("Course Service constructor");
		}
	}

	@Override
	public Course addCourse(Course course) throws CourseException {
		try {
			return cdao.addCourse(course);
		} catch (Exception e) {
			throw new CourseException("Course Insertion Failed");
		}
	}

	@Override
	public Course updateCourse(Course course) throws CourseException {
		
		return cdao.updateCourse(course);
	}

	@Override
	public List<Course> findAll() {	
		return cdao.findAll();
	}

	@Override
	public Course findById(long courseId) {
		return cdao.findById(courseId);
	}

}
