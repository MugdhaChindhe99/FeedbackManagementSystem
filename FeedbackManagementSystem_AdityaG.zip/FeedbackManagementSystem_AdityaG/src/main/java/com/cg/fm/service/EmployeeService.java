package com.cg.fm.service;

import java.util.List;

import com.cg.fm.exception.EmployeeException;
import com.cg.fm.model.Employee;

/**
 * Employee service interface to connect with DAO
 * @author Aditya Ghogale
 *
 */
public interface EmployeeService {

	String namePattern="[A-Za-z ]{4,}";
	
	Employee login(long empId,String password);
	public List<Employee> displayAll() throws Exception;
	public Employee addEmployee(Employee emp) throws Exception;
	public Employee findById(long empId) throws Exception;
	public Employee updateEmployee(Employee e) throws Exception;
	void addProgParticipated(long trainingProgramId) throws EmployeeException;
	void addProgConducted(long trainingProgramId) throws EmployeeException;
	
	
}
