package com.cg.fm.dao;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.cg.fm.exception.TrainingProgramException;
import com.cg.fm.model.TrainingProgram;

/**
 * TrainingProgramDao implementation class with body of methods to perform operation on training program
 * 
 * @author Aditya Ghogale
 *
 */
public class TrainingProgramDaoImpl implements TrainingProgramDao {

	private Map<Long,TrainingProgram> trainingPrograms;
	private Store store;
	
	//Creation of object of Store and creating link between trainingProgram map of this class and trainingPrograms map of Store Class 
	public TrainingProgramDaoImpl() throws TrainingProgramException {
		try {
			store=Store.getInstatnce();
			trainingPrograms=(Map<Long,TrainingProgram>)store.getTrainingProgram();
		} catch (Exception excp) {
			throw new TrainingProgramException("Failed to load program form list");
		}
		
	}

	//Retrieve list of all training programs from file and returns it
	@Override
	public List<TrainingProgram> viewAll() throws TrainingProgramException {
		return trainingPrograms.values().stream().collect(Collectors.toList());
	}

	//Retrieve specific training program form file by id and returns it
	@Override
	public TrainingProgram viewById(long trainingProgramId) throws TrainingProgramException {
		return trainingPrograms.get(trainingProgramId);
	}

	//add new training program to database
	@Override
	public TrainingProgram addTrainingProgram(long trainingProgramId, TrainingProgram trainingProgram)
			throws TrainingProgramException {
		trainingProgram.setTrainingProgramId(trainingProgramId);
		trainingPrograms.put(trainingProgramId, trainingProgram);
		saveToFile();
		return trainingProgram;
	}

	//Actually stores training program to file
	private void saveToFile() throws TrainingProgramException {
		store.setTrainingProgram(trainingPrograms);
		try {
			store.Save();
		} catch (Exception exp) {
			throw new TrainingProgramException(" failed to save Training Program");
		}
	}

	//Update existing training program
	@Override
	public TrainingProgram update(TrainingProgram trainingProgram) throws TrainingProgramException {
		
		return trainingPrograms.replace(trainingProgram.getTrainingProgramId(), trainingProgram);
	}

}
