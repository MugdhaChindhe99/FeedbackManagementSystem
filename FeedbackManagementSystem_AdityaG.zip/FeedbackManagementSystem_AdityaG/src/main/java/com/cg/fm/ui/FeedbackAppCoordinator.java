package com.cg.fm.ui;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.cg.fm.exception.FeedbackException;
import com.cg.fm.exception.TrainingProgramException;
import com.cg.fm.model.Course;
import com.cg.fm.model.Employee;
import com.cg.fm.model.Feedback;
import com.cg.fm.model.TrainingProgram;
import com.cg.fm.service.CourseService;
import com.cg.fm.service.CourseServiceImpl;
import com.cg.fm.service.EmployeeService;
import com.cg.fm.service.EmployeeServiceImpl;
import com.cg.fm.service.FeedbackService;
import com.cg.fm.service.FeedbackServiceImpl;
import com.cg.fm.service.TrainingProgramService;
import com.cg.fm.service.TrainingProgramServiceImpl;

/**
 * FeedbackAppCoordinator UI for calling functionalities of Co-ordinator
 * 
 * @author Aditya Ghogale
 *
 */
public class FeedbackAppCoordinator {

	public static Scanner console = new Scanner(System.in);

	public static void coordinatorPanel() throws Exception {

		do {
			System.out.println("Welcome to Co-ordinator Panel");

			// List of functionalities of co-ordinator
			System.out.println(
					"Select operation\n 1-Add Training Program \n2-Update Training Program \n3-Find by Id \n4-Find All\n5-View Feedback\n6-Logout");
			switch (console.nextInt()) {
			case 1:
				addTrainingProgram();
				break;
			case 2:
				updateTrainingProgram();
				break;
			case 3:
				findProgramById();
				break;
			case 4:
				findAllProgram();
				break;
			case 5:
				viewFeedback();
				break;
			case 6:
				System.out.println("Exiting Feedback System!!!!!");
				System.exit(0);
			default:
				System.out.println("Wrong Choice");
			}
		} while (true);

	}

	// To display list of feedbacks
	private static void viewFeedback() throws FeedbackException {
		// Service object
		FeedbackService feedbackService = new FeedbackServiceImpl();

		List<Feedback> tmpFeedbackList = feedbackService.showFeedbackReport();
		// display list
		for (Feedback fb : tmpFeedbackList) {
			System.out.println(fb);
		}

	}

	// List of all Training Programs
	private static void findAllProgram() throws TrainingProgramException {
		// Service object
		TrainingProgramService trainingProgramService = new TrainingProgramServiceImpl();

		List<TrainingProgram> tmpProgramList = trainingProgramService.viewAll();
		// Display list
		for (TrainingProgram tp : tmpProgramList) {
			System.out.println(tp);
		}
	}

	// To find training program based on id
	private static void findProgramById() throws TrainingProgramException {
		// Service Object
		TrainingProgramService trainingProgramService = new TrainingProgramServiceImpl();
		// Local variable
		long tmpId;
		// Model object
		TrainingProgram tmpProgram;

		console.nextLine();
		System.out.println("Enter training program id to serach for details");
		tmpId = console.nextLong();

		// Retrieve employee from database using id
		tmpProgram = trainingProgramService.viewById(tmpId);
		
		if(tmpProgram!=null)System.out.println(tmpProgram);
		else System.out.println("No training Program with this id exists");
	}

	// To update existing training program
	private static void updateTrainingProgram() throws Exception  {
		// Service object
				TrainingProgramService trainingProgramService = new TrainingProgramServiceImpl();
				CourseService courseService = new CourseServiceImpl();
				EmployeeService employeeService = new EmployeeServiceImpl();

				// Local variable and model object
				long trainingProgramId;
				Course course;
				long hoursPerDay;
				LocalDate startDate;
				LocalDate endDate;
				Employee trainer;
				Set<Employee> participants = new HashSet<>();
				Set<Feedback> feedback = new HashSet<>();
				TrainingProgram tmpProgram = new TrainingProgram();
				String loopV = "y";
				String loopV2 = "y";

				// Accept details from user
				console.nextLine();
				System.out.println("Enter Training Program id");
				trainingProgramId = console.nextLong();
				console.nextLine();
				tmpProgram=trainingProgramService.viewById(trainingProgramId);
				course=tmpProgram.getCourse();
				hoursPerDay=tmpProgram.getHoursPerDay();
				startDate=tmpProgram.getStartDate();
				endDate=tmpProgram.getEndDate();
				trainer=tmpProgram.getTrainer();
				participants=tmpProgram.getParticipants();
				feedback=tmpProgram.getFeedback();
					System.out.println("What do you want to update\n1-CourseId\n2-Duration\n3-Start Date and End Date\n4-Trainer Code\n5-Add new Participant");
					switch (console.nextInt()) {

					case 1:// Change course Id
						console.nextLine();
						System.out.println("Enter course Id");
						try {
						course = courseService.findById(console.nextLong());
						if(course==null)System.out.println("Invalid Course ID");
						}catch(Exception exp) {
							System.out.println("Unable to fetch Course details");
						}
						
						break;

					case 2: // change duration
						do {
						System.out.println("Enter duration per day in hours");
						hoursPerDay = console.nextLong();
						if(hoursPerDay<14) break;
						else System.out.println("Input exceeds daily limit");
						console.nextLine();
						}while(true);
						break;

					case 3:// update start and end date
						do {
							console.nextLine();
							System.out.println("Enter start date in format dd/mm/yyyy");
							startDate = LocalDate.parse(console.nextLine(), DateTimeFormatter.ofPattern("dd/MM/uuuu"));
							LocalDate tmpDateToStart=LocalDate.now().plusWeeks(1);
							if((startDate.compareTo(tmpDateToStart))<0) {
								System.out.println("Start date must be 1 week later todays date");
								continue;
							}
							System.out.println("Enter end date in format dd/mm/yyyy");

							endDate = LocalDate.parse(console.nextLine(), DateTimeFormatter.ofPattern("dd/MM/uuuu"));

							if ((startDate.compareTo(endDate)) < 0)
								break;
							else
								System.out.println("Start date cannot be less than end date. Try again");
						} while (true);
						break;

					case 4:// Change trainer code
						console.nextLine();
						System.out.println("Enter trainer code");
						trainer = employeeService.findById(console.nextLong());
						if(trainer==null)System.out.println("No employee with this ID exists");
						break;

					case 5:// Add new Participant
						Employee tmpEmp;
						do {
							System.out.println("Enter participant id");
							tmpEmp=employeeService.findById(console.nextLong());
							if(tmpEmp!=null) {
								participants.add(tmpEmp);
								employeeService.addProgParticipated(trainingProgramId);
								System.out.println("Participant added");
							}
							else System.out.println("Wrong employee id");
							console.nextLine();
							System.out.println("Want to continue y/n");
							loopV = console.next();
							console.nextLine();
						} while ("y".equalsIgnoreCase(loopV));
						break;
					}


				// set values of training program
				tmpProgram.setTrainingProgramId(trainingProgramId);
				tmpProgram.setCourse(course);
				tmpProgram.setEndDate(endDate);
				tmpProgram.setFeedback(feedback);
				tmpProgram.setHoursPerDay(hoursPerDay);
				tmpProgram.setParticipants(participants);
				tmpProgram.setTrainer(trainer);
				tmpProgram.setStartDate(startDate);
				// Update training program
				trainingProgramService.update(tmpProgram);
				employeeService.addProgConducted(tmpProgram.getTrainingProgramId());
				System.out.println("Program Updated");

	}

	// Add new training program in database

	private static void addTrainingProgram() throws Exception {
		// Service object
				TrainingProgramService trainingProgramService = new TrainingProgramServiceImpl();
				CourseService courseService = new CourseServiceImpl();
				EmployeeService employeeService = new EmployeeServiceImpl();

				// Local variable and model object
				long trainingProgramId=999999;
				Course course=new Course();
				long hoursPerDay;
				LocalDate startDate;
				LocalDate endDate;
				Employee trainer;
				Set<Employee> participants = new HashSet<>();
				Set<Feedback> feedback = new HashSet<>();
				TrainingProgram tmpProgram = new TrainingProgram();
				String loopV = "y";

				// Accept input from user
				try {
				console.nextLine();
				System.out.println("Enter Training Program id");
				trainingProgramId = console.nextLong();}
				catch(InputMismatchException exp) {
					System.out.println("Training Id can contain numeric values only.");
					FeedbackAppCoordinator.addTrainingProgram();
				}
				console.nextLine();
				
				try {
				System.out.println("Enter course Id");
				course = courseService.findById(console.nextLong());
				if(course==null) {
					System.out.println("No course with this id exist");
					FeedbackAppCoordinator.addTrainingProgram();
				}
				}catch(InputMismatchException exp) {
					System.out.println("Invalid course Id");
					FeedbackAppCoordinator.addTrainingProgram();
				}
				console.nextLine();
				
				//accept duration per hour
				do {
				System.out.println("Enter duration per day in hours");
				hoursPerDay = console.nextLong();
				if(hoursPerDay<16) break;
				else System.out.println("Input exceeds daily limit");
				console.nextLine();
				}while(true);
				
				// accept start date and end date and validate whether start date is less than
				// end date
				do {
					console.nextLine();
					System.out.println("Enter start date in format dd/mm/yyyy");
					startDate = LocalDate.parse(console.nextLine(), DateTimeFormatter.ofPattern("dd/MM/uuuu"));
					
					LocalDate tmpDateToStart=LocalDate.now().plusWeeks(1);
					if((startDate.compareTo(tmpDateToStart))<0) {
						System.out.println("Start date must be 1 week later todays date");
						continue;
					}

					System.out.println("Enter end date in format dd/mm/yyyy");

					endDate = LocalDate.parse(console.nextLine(), DateTimeFormatter.ofPattern("dd/MM/uuuu"));

					if ((startDate.compareTo(endDate)) < 0)
						break;
					else
						System.out.println("Start date cannot be less than end date. Try again");
				} while (true);

				System.out.println("Enter trainer code");
				trainer = employeeService.findById(console.nextLong());
				console.nextLine();

				do {
					System.out.println("Enter participant id");
					participants.add(employeeService.findById(console.nextLong()));
					console.nextLine();
					System.out.println("Want to continue y/n");
					loopV = console.next();
					console.nextLine();
				} while ("y".equalsIgnoreCase(loopV));
				
				

				// set values of training program
				tmpProgram.setCourse(course);
				tmpProgram.setEndDate(endDate);
				tmpProgram.setFeedback(feedback);
				tmpProgram.setHoursPerDay(hoursPerDay);
				tmpProgram.setParticipants(participants);
				tmpProgram.setTrainer(trainer);
				tmpProgram.setStartDate(startDate);

				// add training program
				
				TrainingProgram tp = trainingProgramService.addTrainingProgram(trainingProgramId, tmpProgram);
				System.out.println("Training program with ID:" + tp.getTrainingProgramId());
				employeeService.addProgParticipated(trainingProgramId);
				employeeService.addProgConducted(tmpProgram.getTrainingProgramId());
	}

}
