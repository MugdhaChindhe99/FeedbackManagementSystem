package com.cg.fm.exception;

public class InvalidNameException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1254519258977725947L;
	String name;

	public InvalidNameException(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "InvalidName [name=" + name + "]";
	}
	
}
