package com.cg.fm.exception;

public class InvalidUserDetailsException extends Exception {

	public InvalidUserDetailsException() {
		System.out.println("Invalid User Role...Please Contact to Admin");
	}

}
