package com.cg.fm.service;

public interface FacultyService {

}
