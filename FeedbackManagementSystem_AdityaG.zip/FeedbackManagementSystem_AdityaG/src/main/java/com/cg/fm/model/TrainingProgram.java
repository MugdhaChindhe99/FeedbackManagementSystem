package com.cg.fm.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * This class will take input from multiple class and store object for course
 * 
 * @author Aditya Ghogale
 *
 */
public class TrainingProgram implements Serializable {

	private long trainingProgramId;
	private Course course;
	private long hoursPerDay;
	private LocalDate startDate;
	private LocalDate endDate;
	private Employee trainer;
	private Set<Employee> participants;
	private Set<Feedback> feedback;
	
	public TrainingProgram() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TrainingProgram(long trainingProgramId, Course course, long hoursPerDay, LocalDate startDate,
			LocalDate endDate, Employee trainer, Set<Employee> participants, Set<Feedback> feedback) {
		super();
		this.trainingProgramId = trainingProgramId;
		this.course = course;
		this.hoursPerDay = hoursPerDay;
		this.startDate = startDate;
		this.endDate = endDate;
		this.trainer = trainer;
		this.participants = participants;
		this.feedback = feedback;
	}
	public long getTrainingProgramId() {
		return trainingProgramId;
	}
	public void setTrainingProgramId(long trainingProgramId) {
		this.trainingProgramId = trainingProgramId;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	public long getHoursPerDay() {
		return hoursPerDay;
	}
	public void setHoursPerDay(long hoursPerDay) {
		this.hoursPerDay = hoursPerDay;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate2) {
		this.startDate = startDate2;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate2) {
		this.endDate = endDate2;
	}
	public Employee getTrainer() {
		return trainer;
	}
	public void setTrainer(Employee trainer) {
		this.trainer = trainer;
	}
	public Set<Employee> getParticipants() {
		return participants;
	}
	public void setParticipants(Set<Employee> participants) {
		this.participants = participants;
	}
	public Set<Feedback> getFeedback() {
		return feedback;
	}
	public void setFeedback(Set<Feedback> feedback) {
		this.feedback = feedback;
	}
	@Override
	public String toString() {
		Set<String> participantList=participants.stream().map(e->e.getEmployeeName()).collect(Collectors.toSet());
		return "\nTrainingProgram \ntrainingProgramId=" + trainingProgramId + "\n course=" + course + "\n hoursPerDay="
				+ hoursPerDay + "\n startDate=" + startDate + "\t endDate=" + endDate + "\n trainer=" + trainer.getEmployeeName()
				+ "\t participants=" +participantList+ "\n feedback=" + feedback+"\n";
	}
	

	
}
