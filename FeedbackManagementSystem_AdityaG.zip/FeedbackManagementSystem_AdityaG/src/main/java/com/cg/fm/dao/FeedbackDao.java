package com.cg.fm.dao;

import java.util.List;

import com.cg.fm.exception.FeedbackException;
import com.cg.fm.model.Feedback;

public interface FeedbackDao {

	Feedback giveFeedback(Feedback fb) throws FeedbackException;

	List<Feedback> showFeedbackReport() throws FeedbackException;
}
