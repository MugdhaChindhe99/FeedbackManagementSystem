package com.cg.fm.ui;

import java.util.Scanner;

import com.cg.fm.exception.InvalidUserDetailsException;
import com.cg.fm.model.Employee;
import com.cg.fm.service.EmployeeService;
import com.cg.fm.service.EmployeeServiceImpl;

/**
 * Client class with main method through which execution of application starts
 * 
 * @author Aditya Ghogale
 *
 */
public class FeedbackAppClient {
	
	public static void main(String[] args) throws Exception {
		// service object
		EmployeeService employeeService = new EmployeeServiceImpl();

		// declaration of local variables and model object
		long tmpId;
		String tmpRole = null;
		String tmpPassword = null;
		Employee tmpEmployee = new Employee();
		
		Scanner console = new Scanner(System.in);

		// Console app starting point
		System.out.println("Welcome to Feedback Management System !!!");

		do {
			System.out.println("Login Panel");
			System.out.println("Enter user id");
			tmpId = console.nextLong();
			console.nextLine();
			System.out.println("Enter password");
			tmpPassword = console.nextLine();
			tmpEmployee = employeeService.login(tmpId, tmpPassword);
			if (null != tmpEmployee) {
				tmpRole = tmpEmployee.getRole();
				switch (tmpRole.toUpperCase()) {
				case "ADMIN":
					FeedbackAppAdmin.adminPanel();break;  //throw control of execution to adminPanel() of FeedbackAppAdmin class
				case "COORDINATOR":
					FeedbackAppCoordinator.coordinatorPanel();break; //throw control of execution to coordinatorPanel() of FeedbackAppCoordinatorclass
				case "PARTICIPANT":
					FeedbackAppParticipant.participantPanel();break; //throw control of execution to participantPanel() of FeedbackAppParticipant class
				default:
					console.close();
					throw new InvalidUserDetailsException();
				}
			} else
				System.out.println("Wrong username or Password");
		} while (true);
	

	}

}
