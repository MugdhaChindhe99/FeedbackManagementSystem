package com.cg.fm.dao;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.cg.fm.exception.EmployeeException;
import com.cg.fm.exception.EmployeeNotFoundException;
import com.cg.fm.model.Employee;
import com.cg.fm.model.TrainingProgram;

/**
 * Employee Dao methods implementation
 * 
 * @author Aditya Ghogale
 *
 */
public class EmployeeDaoImpl implements EmployeeDao {

	private Map<Long, Employee> employee;
	private Map<Long, TrainingProgram> trainingPrograms;
	private Store store;

	public EmployeeDaoImpl() throws EmployeeException {
		try {
			store = Store.getInstatnce();
			employee = (Map<Long, Employee>) store.getEmployees();
			trainingPrograms = store.getTrainingProgram();
		} catch (Exception e) {
			throw new EmployeeException("Constructor of EmployeeDao");
		}

	}

	@Override
	public Employee login(long empId, String password) {
		Employee e;
		if ((e = employee.get(empId)) != null) {
			if (e.getPassword().equals(password)) {
				System.out.println("Login Successfully !!!");
				return e;
			} else
				System.out.println("Invalid password");
		} else
			System.out.println("Invalid userId");

		return null;
	}

	@Override
	public List<Employee> findAll() {

		return employee.values().stream().collect(Collectors.toList());
	}

	@Override
	public Employee addEmployee(long empId, Employee emp) throws EmployeeException {
		employee.put(empId, emp);
		try {
			saveToStore();
		} catch (Exception e) {
			throw new EmployeeException("Problem in Dao");
		}
		return emp;
	}

	private void saveToStore() throws Exception {
		store.setEmployees(employee);
		store.Save();

	}

	@Override
	public Employee findById(long empId) throws EmployeeNotFoundException {
		// try {
		return employee.get(empId);
		/*
		 * }catch(Exception e) { throw new
		 * EmployeeNotFoundException("No employee With "+empId+" found"); }
		 */
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		return employee.replace(emp.getEmployeeId(), emp);
	}

	@Override
	public void addProgParticipated(long trainingProgramId) throws EmployeeException {
		TrainingProgram tp = trainingPrograms.get(trainingProgramId);
		List<Employee> empList = tp.getParticipants().stream().collect(Collectors.toList());
		for (Employee tmpEmp : empList) {
			tmpEmp.setTrainingProgramParticipated(tp);
			employee.replace(tmpEmp.getEmployeeId(), tmpEmp);
		}
		try {
			saveToStore();
		} catch (Exception e) {
			throw new EmployeeException("Cannot Add Participant");
		}

	}

	@Override
	public void addProgConducted(long trainingProgramId) throws EmployeeException {
		TrainingProgram tmpProgram = trainingPrograms.get(trainingProgramId);
		Employee tmpEmp = tmpProgram.getTrainer();
		tmpEmp.setTrainingProgramConducted(tmpProgram);
		try {
			saveToStore();
		} catch (Exception e) {
			throw new EmployeeException("Cannot Add Trainer");
		}

	}

}
