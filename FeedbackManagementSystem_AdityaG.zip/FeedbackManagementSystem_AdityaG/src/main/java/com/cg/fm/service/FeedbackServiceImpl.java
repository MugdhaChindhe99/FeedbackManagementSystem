package com.cg.fm.service;

import java.util.List;

import com.cg.fm.dao.FeedbackDao;
import com.cg.fm.dao.FeedbackDaoImpl;
import com.cg.fm.exception.FeedbackException;
import com.cg.fm.model.Feedback;

public class FeedbackServiceImpl implements FeedbackService {

	private FeedbackDao fdao;
	
	public FeedbackServiceImpl() throws FeedbackException {
		try {
			fdao=new FeedbackDaoImpl();
		} catch (Exception e) {
			throw new FeedbackException("Service of Feedback");
		}
	}

	@Override
	public Feedback giveFeedback(Feedback fb) throws FeedbackException {
		
		return fdao.giveFeedback(fb);
	}

	@Override
	public List<Feedback> showFeedbackReport() throws FeedbackException {
		// TODO Auto-generated method stub
		return fdao.showFeedbackReport();
	}

}
