package com.cg.fm.service;

import java.util.List;

import com.cg.fm.dao.SkillDao;
import com.cg.fm.dao.SkillDaoImpl;
import com.cg.fm.exception.SkillException;
import com.cg.fm.model.Skill;

/**
 * Implementation of skill service interface
 * @author Aditya Ghogale
 *
 */
public class SkillServiceImpl implements SkillService {

	private SkillDao skdao;
	
	//create objects of SkillDaoImpl 
	public SkillServiceImpl() throws SkillException{
		
		try {
			skdao=new SkillDaoImpl();
		} catch (Exception e) {
			throw new SkillException("Exception in constructor of ServiceImpl");
		}
		
	}
	
	//Call method of SkillDao and passes object of Skill to add new Skill
	@Override
	public Skill addSkills(Skill skill) throws SkillException {
		return skdao.addSkills(skill);
	}

	//it will call method of SkillDao which returns list of all skills
	@Override
	public List<Skill> findAll() {
		return skdao.findAll();
	}

	//it will pass skillId to method of SkillDao to fetch record of specific skill
	@Override
	public Skill findById(long skillId) {
		return skdao.findById(skillId);
	}

}
