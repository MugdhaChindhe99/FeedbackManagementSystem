package com.cg.fm.exception;

/**
 * TrainingProgramException body
 * This exception is thrown when there is problem in performing training program operation
 * 
 * @author Aditya Ghogale
 *
 */
public class TrainingProgramException extends Exception {

	private String message;

	public TrainingProgramException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String toString() {
		return "TrainingProgramException message=" + message;
	}
	
}
