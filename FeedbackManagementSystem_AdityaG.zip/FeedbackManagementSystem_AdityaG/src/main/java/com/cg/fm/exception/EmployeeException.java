package com.cg.fm.exception;

/**
 * Employee excption will be thrown when there is problem in employee entity
 * 
 * @author Aditya Ghogale
 *
 */
public class EmployeeException extends Exception {

	private String message;

	public EmployeeException(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "EmployeeException message=" + message ;
	}	
}
