package com.cg.fm.dao;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.cg.fm.exception.FeedbackException;
import com.cg.fm.model.Feedback;

public class FeedbackDaoImpl implements FeedbackDao {
 private  Map<Long,Feedback> feedbacks;
 private Store store;
 
	public FeedbackDaoImpl() throws Exception {
	store=Store.getInstatnce();
	feedbacks=Store.getInstatnce().getFeedbacks();
}
	@Override
	public Feedback giveFeedback(Feedback feedback) throws FeedbackException {
		feedbacks.put(feedback.getFeedbackId(),feedback);
		storeToFile();
		return feedback;
	}
	private void storeToFile() throws FeedbackException {
		store.setFeedbacks(feedbacks);
		try {
			store.Save();
		} catch (Exception e) {
			throw new FeedbackException("Feedback Cannot be provided");
		}
		
	}
	@Override
	public List<Feedback> showFeedbackReport() throws FeedbackException {
		
		return feedbacks.values().stream().collect(Collectors.toList());
	}

	

}
