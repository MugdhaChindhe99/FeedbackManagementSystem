package com.cg.fm.service;

import java.util.List;

import com.cg.fm.exception.CourseException;
import com.cg.fm.model.Course;

/**
 * Course service interface to connect with DAO
 * 
 * @author Aditya Ghogale
 *
 */
public interface CourseService {

	Course addCourse(Course course) throws CourseException;

	Course updateCourse(Course course) throws CourseException;

	List<Course> findAll();

	Course findById(long courseId);
}
