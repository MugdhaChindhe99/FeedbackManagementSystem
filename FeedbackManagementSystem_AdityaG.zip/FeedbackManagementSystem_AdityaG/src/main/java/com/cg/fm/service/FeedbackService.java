package com.cg.fm.service;

import java.util.List;

import com.cg.fm.exception.FeedbackException;
import com.cg.fm.model.Feedback;

public interface FeedbackService {

	Feedback giveFeedback(Feedback fb) throws FeedbackException;

	List<Feedback> showFeedbackReport() throws FeedbackException;
}
