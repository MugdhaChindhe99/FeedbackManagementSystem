package com.cg.fm.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.cg.fm.exception.SkillException;
import com.cg.fm.model.Skill;

/**
 * Implementation of skill interface with body of methods
 * 
 * @author Aditya Ghogale
 *
 */
public class SkillDaoImpl implements SkillDao {

	// initialization of map to store reference of skills from Store class
	private  Map<Long, Skill> skills;

	//predefine some skills
	public SkillDaoImpl() {
		skills=new HashMap<>();
		Skill sk1=new Skill(1111,"Java");
		Skill sk2=new Skill(2222,"C");
		Skill sk3=new Skill(3333,"C++");
		Skill sk4=new Skill(4444,"Pyton");
		Skill sk5=new Skill(5555,"HTML");
		Skill sk6=new Skill(6666,"JavaScript");
		Skill sk7=new Skill(7777,"JQuery");
		skills.put(sk1.getSkillId(),sk1);
		skills.put(sk2.getSkillId(),sk2);
		skills.put(sk3.getSkillId(),sk3);
		skills.put(sk4.getSkillId(),sk4);
		skills.put(sk5.getSkillId(),sk5);
		skills.put(sk6.getSkillId(),sk6);
		skills.put(sk7.getSkillId(),sk7);
	}

	@Override
	public Skill addSkills(Skill skill) throws SkillException {
		return skills.put(skill.getSkillId(), skill);
	}

	@Override
	public List<Skill> findAll() {
		
		return skills.values().stream().collect(Collectors.toList());
	}

	@Override
	public Skill findById(long skillId) {
		return skills.get(skillId);
	}
	
	/*// object of store class
	private Store store;

	// initialization of objects
	public SkillDaoImpl() throws SkillException{
		try {
			store = Store.getInstatnce();
			skills = store.getSkills();
		} catch (Exception exp) {
			
			throw new SkillException("Skill Dao Constructor");
		}
		
	}

	// To add new skill
	@Override
	public Skill addSkills(Skill skill) throws SkillException {
		skills.put(skill.getSkillId(), skill);
		saveToFile();
		return skill;
	}

	// to actually store changes in file
	private void saveToFile() throws SkillException {
		store.setSkills(skills);
		try {
			store.Save();
		} catch (Exception exe) {
			throw new SkillException("Skill can't be added");
		}

	}

	// return list of all skills
	@Override
	public List<Skill> findAll() {

		return skills.values().stream().collect(Collectors.toList());
	}

	// find skill by id
	@Override
	public Skill findById(long skillId) {
		return skills.get(skillId);
	}*/
	
	

}
