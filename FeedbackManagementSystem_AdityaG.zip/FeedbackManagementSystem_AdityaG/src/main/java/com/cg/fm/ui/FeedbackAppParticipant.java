package com.cg.fm.ui;

import java.util.Random;
import java.util.Scanner;

import com.cg.fm.exception.EmployeeException;
import com.cg.fm.exception.EmployeeNotFoundException;
import com.cg.fm.exception.FeedbackException;
import com.cg.fm.exception.TrainingProgramException;
import com.cg.fm.model.Employee;
import com.cg.fm.model.Feedback;
import com.cg.fm.model.TrainingProgram;
import com.cg.fm.service.EmployeeService;
import com.cg.fm.service.EmployeeServiceImpl;
import com.cg.fm.service.FeedbackService;
import com.cg.fm.service.FeedbackServiceImpl;
import com.cg.fm.service.TrainingProgramService;
import com.cg.fm.service.TrainingProgramServiceImpl;

/**
 * FeedbackAppParticipant UI for calling functionalities of Participant
 * 
 * @author Aditya Ghogale
 * @throws EmployeeNotFoundException
 * @throws FeedbackException
 * @throws TrainingProgramException
 *
 */
public class FeedbackAppParticipant {

	public static Scanner console = new Scanner(System.in);

	public static void participantPanel()
			throws Exception {

		// Service objects
		FeedbackService feedbackService = new FeedbackServiceImpl();
		EmployeeService employeeService = new EmployeeServiceImpl();
		TrainingProgramService trainingProgramService = new TrainingProgramServiceImpl();

		// model objects
		Feedback tmpFeedback = new Feedback();
		Employee participant = new Employee();
		TrainingProgram trainingProgram = new TrainingProgram();

		// Local variables
		long feedbackId;
		int fbPrsComm;
		int fbClrfyDbts;
		int fbTM;
		int fbHndOut;
		int fbHwSwNtwrk;
		String comments;
		String suggestion;

		// feedbackId is random auto generated number
		feedbackId = generateFeedbackId();

	
		System.out.println("Enter program Id");
		trainingProgram = trainingProgramService.viewById(console.nextLong());
		if(trainingProgram==null) {
			System.out.println("Incorrect training program id");
			FeedbackAppParticipant.participantPanel();
		}

		// check if training program details is fetched or not.If no training program
		// found raise TrainingProgramException
		console.nextLine();

		System.out.println("Enter participant Id");
		participant=employeeService.findById(console.nextLong());
		console.nextLine();
		
		if (participant == null) {
			System.out.println("Incorrect participant id");
			FeedbackAppParticipant.participantPanel();
		}
		
		// Feedback parameter levels
		System.out.println("5-Excellent: �Ideal way of doing it�\r\n"
				+ "4-Good: �No pain areas or concern but could have been better�\r\n"
				+ "3-Average: �There are concerns but not significant�\r\n"
				+ "2-Below Average: �Needs improvement and is salvageable�\r\n"
				+ "1-Poor: �This way of doing things must change�\r\n");

		// Accept rating in scale 1-5 where 5 is excellent and 1 is poor
		System.out.println("Rate communication between 1-5");
		fbPrsComm = console.nextInt();
		console.nextLine();
		System.out.println("Rate clarify doubts between 1-5");
		fbClrfyDbts = console.nextInt();
		console.nextLine();
		System.out.println("Rate time management between 1-5");
		fbTM = console.nextInt();
		console.nextLine();
		System.out.println("Rate hand-outs between 1-5");
		fbHndOut = console.nextInt();
		console.nextLine();
		System.out.println("Rate hardware and software network between 1-5");
		fbHwSwNtwrk = console.nextInt();
		console.nextLine();
		System.out.println("Give any comment");
		comments = console.nextLine();
		System.out.println("Give Suggestion");
		suggestion = console.nextLine();

		// add values to feedback object
		tmpFeedback.setFeedbackId(feedbackId);
		tmpFeedback.setParticipant(participant);
		tmpFeedback.setTrainingProgram(trainingProgram);
		tmpFeedback.setFB_clrfy_dbts(fbClrfyDbts);
		tmpFeedback.setFB_Hnd_out(fbHndOut);
		tmpFeedback.setFB_prs_comm(fbPrsComm);
		tmpFeedback.setFB_TM(fbTM);
		tmpFeedback.setFB_Hw_Sw_Ntwrk(fbHwSwNtwrk);
		tmpFeedback.setComments(comments);
		tmpFeedback.setSuggestion(suggestion);

		// save feedback
		System.out.println("Feedback is saved with ID :" + feedbackService.giveFeedback(tmpFeedback).getFeedbackId());
	}

	// To generate random feedback id
	private static long generateFeedbackId() {
		Random r = new Random();
		return r.nextInt(1000);
	}

}
