package com.cg.fm.dao;

import java.util.List;

import com.cg.fm.exception.TrainingProgramException;
import com.cg.fm.model.TrainingProgram;

/**
 * Training Program interface with methods declaration to perform operations on training program
 * @author Aditya Ghogale
 *
 */
public interface TrainingProgramDao {

	List<TrainingProgram> viewAll() throws TrainingProgramException;

	TrainingProgram viewById(long trainingProgramId) throws TrainingProgramException;

	TrainingProgram addTrainingProgram(long trainingProgramId, TrainingProgram trainingProgram) throws TrainingProgramException;

	TrainingProgram update(TrainingProgram tarainingProgram) throws TrainingProgramException;
}
