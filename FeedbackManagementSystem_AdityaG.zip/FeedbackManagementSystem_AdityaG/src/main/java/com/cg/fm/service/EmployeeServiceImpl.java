package com.cg.fm.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.cg.fm.dao.EmployeeDao;
import com.cg.fm.dao.EmployeeDaoImpl;
import com.cg.fm.exception.EmployeeException;
import com.cg.fm.exception.EmployeeNotFoundException;
import com.cg.fm.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeDao edao;

	public EmployeeServiceImpl() throws EmployeeNotFoundException {
		try {
			edao = new EmployeeDaoImpl();
		} catch (Exception e) {
			throw new EmployeeNotFoundException("Hello");
		}

	}

	@Override
	public Employee login(long empId, String password) {
		return edao.login(empId, password);
	}

	@Override
	public List<Employee> displayAll() throws EmployeeNotFoundException {
		List<Employee> ls=new ArrayList<>();
		try {
			ls = (List<Employee>) edao.findAll();
		} catch (Exception e) {
			throw new EmployeeNotFoundException("No Records Found");
		}
		if (ls != null)
			return ls;
		else
			throw new EmployeeNotFoundException("No Records Found");
	}

	@Override
	public Employee addEmployee(Employee emp) throws EmployeeException {
		long id = generateEmpId();
		emp.setEmployeeId(id);
		try {
			return edao.addEmployee(id, emp);
		} catch (Exception e) {
			throw new EmployeeException("Error in saving details");
		}
	}

	private int generateEmpId() {
		Random tmpId = new Random();
		return tmpId.nextInt(1000) * 395;
	}

	@Override
	public Employee findById(long empId) throws EmployeeNotFoundException {
			return edao.findById(empId);
	}

	@Override
	public Employee updateEmployee(Employee e) throws Exception {
		return edao.updateEmployee(e);
	}

	@Override
	public void addProgParticipated(long trainingProgramId) throws EmployeeException {
		edao.addProgParticipated(trainingProgramId);
		
	}

	@Override
	public void addProgConducted(long trainingProgramId) throws EmployeeException {
		edao.addProgConducted(trainingProgramId);
		
	}

}
