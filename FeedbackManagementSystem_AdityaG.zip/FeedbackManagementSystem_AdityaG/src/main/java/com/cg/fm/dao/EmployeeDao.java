package com.cg.fm.dao;

import java.util.List;

import com.cg.fm.exception.EmployeeException;
import com.cg.fm.exception.EmployeeNotFoundException;
import com.cg.fm.exception.InvalidUserDetailsException;
import com.cg.fm.model.Employee;

/**
 * Employee interface file.
 * @author Aditya Ghogale
 *
 */
public interface EmployeeDao {

	public Employee login(long empId, String password);
	public List<Employee> findAll() throws EmployeeException;
	public Employee addEmployee(long empId,Employee emp) throws EmployeeException;
	public Employee findById(long empId) throws EmployeeNotFoundException;
	public Employee updateEmployee(Employee emp) throws InvalidUserDetailsException;
	void addProgParticipated(long trainingProgramId) throws EmployeeException;
	void addProgConducted(long trainingProgramId) throws EmployeeException;
	
}
